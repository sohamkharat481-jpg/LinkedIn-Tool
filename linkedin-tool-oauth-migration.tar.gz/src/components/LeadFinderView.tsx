import React, { useState } from 'react';
import { Client, LeadFilter, LeadProviderConfig, SeniorityLevel, CompanySizeRange, RawLead, SearchProgressState, ProviderStatusInfo } from '../types';
import { Search, Sparkles, Filter, CheckCircle2, Loader2, AlertTriangle, ArrowRight, ShieldCheck, Tag, XCircle, Settings, Link, User, Globe, Building2 } from 'lucide-react';
import { apiUrl } from '../services/apiClient';
import type { LeadPersistenceStatus } from '../services/supabaseDataService';

interface LeadFinderViewProps {
  clients: Client[];
  activeClient: Client | null;
  onSelectClient: (clientId: string) => void;
  onExecuteSearch: (filters: LeadFilter, targetClient: Client) => Promise<{
    uniqueLeads: RawLead[];
    candidatesFound: number;
    duplicatesRemoved: number;
    finalCount: number;
    persistenceStatus: LeadPersistenceStatus;
    persistenceMessage: string;
  }>;
  onNavigateToLeads: () => void;
  onNavigateToSettings: () => void;
  providerStatus: ProviderStatusInfo;
  providerType: LeadProviderConfig['providerType'];
  onEnableMockMode?: () => void;
}

const SENIORITY_OPTIONS: SeniorityLevel[] = ['Entry', 'Manager', 'Senior', 'Director', 'VP', 'C-Level'];
const COMPANY_SIZE_OPTIONS: CompanySizeRange[] = ['1-10', '11-50', '51-200', '201-500', '501-1000', '1001+'];

const POPULAR_COUNTRIES = [
  'United States',
  'United Kingdom',
  'Canada',
  'Australia',
  'India',
  'Germany',
  'France',
  'Singapore',
  'United Arab Emirates',
  'Brazil'
];

const POPULAR_JOB_TITLE_PRESETS = [
  'Founder',
  'CEO',
  'Marketing Manager',
  'VP of Sales',
  'Chief Medical Officer',
  'Director of Operations',
  'CTO',
  'Managing Director',
  'Clinical Director'
];

const POPULAR_INDUSTRY_PRESETS = [
  'Healthcare',
  'Technology & SaaS',
  'Hospitals & Medical Practice',
  'Financial Services',
  'Real Estate',
  'Marketing & Advertising',
  'Management Consulting'
];

export const LeadFinderView: React.FC<LeadFinderViewProps> = ({
  clients,
  activeClient,
  onSelectClient,
  onExecuteSearch,
  onNavigateToLeads,
  onNavigateToSettings,
  providerStatus,
  providerType,
  onEnableMockMode
}) => {
  // Search Mode state: 'manual' | 'profile'
  const [searchMode, setSearchMode] = useState<'manual' | 'profile'>('manual');

  // LinkedIn Profile Mode state
  const [clientProfileUrl, setClientProfileUrl] = useState('');
  const [profileInputError, setProfileInputError] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analyzedIcp, setAnalyzedIcp] = useState<{
    jobTitles: string[];
    industry: string[];
    seniority: SeniorityLevel[];
    country: string;
    city: string;
    companySize: CompanySizeRange[];
    keywords: string;
  } | null>(null);

  // Manual Form State
  const [jobTitles, setJobTitles] = useState<string[]>(['Founder', 'CEO', 'Marketing Manager']);
  const [titleInput, setTitleInput] = useState('');
  
  const [industries, setIndustries] = useState<string[]>(['Technology & SaaS']);
  const [industryInput, setIndustryInput] = useState('');

  const [country, setCountry] = useState('United States');
  const [city, setCity] = useState('');

  const [seniority, setSeniority] = useState<SeniorityLevel[]>(['Director', 'VP', 'C-Level']);
  const [companySize, setCompanySize] = useState<CompanySizeRange[]>(['11-50', '51-200']);

  const [maxLeads, setMaxLeads] = useState<number>(50);

  // Execution & Progress State
  const [isSearching, setIsSearching] = useState(false);
  const [progressState, setProgressState] = useState<SearchProgressState | null>(null);
  const [searchResultSummary, setSearchResultSummary] = useState<{
    candidatesFound: number;
    duplicatesRemoved: number;
    finalCount: number;
    persistenceStatus: LeadPersistenceStatus;
    persistenceMessage: string;
    uniqueLeads?: RawLead[];
  } | null>(null);
  const [searchError, setSearchError] = useState<string | null>(null);

  // Tag helper functions
  const handleAddJobTitle = (titleToAdd: string) => {
    const trimmed = titleToAdd.trim();
    if (trimmed && !jobTitles.includes(trimmed)) {
      setJobTitles([...jobTitles, trimmed]);
      setTitleInput('');
    }
  };

  const handleRemoveJobTitle = (titleToRemove: string) => {
    setJobTitles(jobTitles.filter((t) => t !== titleToRemove));
  };

  const handleAddIndustry = (indToAdd: string) => {
    const trimmed = indToAdd.trim();
    if (trimmed && !industries.includes(trimmed)) {
      setIndustries([...industries, trimmed]);
      setIndustryInput('');
    }
  };

  const handleRemoveIndustry = (indToRemove: string) => {
    setIndustries(industries.filter((i) => i !== indToRemove));
  };

  const toggleSeniority = (level: SeniorityLevel) => {
    if (seniority.includes(level)) {
      setSeniority(seniority.filter((s) => s !== level));
    } else {
      setSeniority([...seniority, level]);
    }
  };

  const toggleCompanySize = (size: CompanySizeRange) => {
    if (companySize.includes(size)) {
      setCompanySize(companySize.filter((c) => c !== size));
    } else {
      setCompanySize([...companySize, size]);
    }
  };

  const handleAnalyzeProfile = async () => {
    const url = clientProfileUrl.trim();
    const linkedInRegex = /https?:\/\/(www\.)?linkedin\.com\/in\/[\w-]+/i;

    if (!url) {
      setProfileInputError('Please enter a LinkedIn profile URL.');
      return;
    }

    if (!linkedInRegex.test(url)) {
      setProfileInputError('Invalid LinkedIn profile URL. Example: https://www.linkedin.com/in/example');
      return;
    }

    setProfileInputError(null);
    setIsAnalyzing(true);
    setAnalyzedIcp(null);

    try {
      const res = await fetch(apiUrl('/api/analyze-profile'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ profileUrl: url })
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Failed to analyze LinkedIn profile.');
      }

      setAnalyzedIcp(data.icp);
    } catch (err: any) {
      setProfileInputError(err.message || 'Error communicating with profile analyzer.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleRunSearch = async (overrideFilters?: LeadFilter) => {
    if (!activeClient) {
      setSearchError('Please select or create an active target client first.');
      return;
    }

    let activeJobTitles = overrideFilters ? overrideFilters.jobTitles : [...jobTitles];
    if (activeJobTitles.length === 0 && titleInput.trim()) {
      activeJobTitles = [titleInput.trim()];
      setJobTitles(activeJobTitles);
      setTitleInput('');
    }

    if (activeJobTitles.length === 0) {
      setSearchError('At least one job title is required.');
      return;
    }

    let activeIndustries = overrideFilters ? overrideFilters.industry : [...industries];
    if (industryInput.trim() && !activeIndustries.includes(industryInput.trim())) {
      activeIndustries.push(industryInput.trim());
      setIndustries(activeIndustries);
      setIndustryInput('');
    }

    setIsSearching(true);
    setSearchError(null);
    setSearchResultSummary(null);

    const filters: LeadFilter = {
      ...(overrideFilters || {
        jobTitles: activeJobTitles,
        industry: activeIndustries,
        country,
        city: city.trim() || undefined,
        seniority,
        companySize,
        maxLeads: Math.min(Math.max(maxLeads, 1), 500)
      })
    };

    try {
      setProgressState({ step: 1, message: 'Preparing search parameters...' });
      await new Promise((r) => setTimeout(r, 300));

      setProgressState({ step: 2, message: 'Connecting to server lead provider...' });
      
      const result = await onExecuteSearch(filters, activeClient);

      setProgressState({ step: 3, message: 'Validating public lead records...' });
      await new Promise((r) => setTimeout(r, 300));

      setProgressState({ step: 4, message: 'Deduplicating provider records...' });
      await new Promise((r) => setTimeout(r, 300));

      setProgressState({ step: 5, message: 'Saving unique leads to client database...' });
      await new Promise((r) => setTimeout(r, 200));

      setSearchResultSummary({
        candidatesFound: result.candidatesFound,
        duplicatesRemoved: result.duplicatesRemoved,
        finalCount: result.finalCount,
        persistenceStatus: result.persistenceStatus,
        persistenceMessage: result.persistenceMessage,
        uniqueLeads: result.uniqueLeads
      });
    } catch (err: any) {
      setSearchError(err.message || 'An error occurred while finding leads.');
    } finally {
      setIsSearching(false);
      setProgressState(null);
    }
  };

  const handleSearchWithAnalyzedIcp = () => {
    if (!analyzedIcp) return;
    const filters: LeadFilter = {
      jobTitles: analyzedIcp.jobTitles,
      industry: analyzedIcp.industry,
      country: analyzedIcp.country,
      city: analyzedIcp.city || undefined,
      seniority: analyzedIcp.seniority,
      companySize: analyzedIcp.companySize,
      maxLeads: Math.min(Math.max(maxLeads, 1), 500),
      keywords: analyzedIcp.keywords
    };
    handleRunSearch(filters);
  };

  const isNotConfigured = !providerStatus.isMock && providerStatus.status === 'Not Configured';

  return (
    <div id="lead-finder-section" className="space-y-6 max-w-5xl mx-auto scroll-mt-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 tracking-tight">Find Potential Customers</h1>
          <p className="text-xs text-gray-500 mt-1">
            Discover relevant public B2B leads via Manual Filters or LinkedIn Profile Mode.
          </p>
        </div>

        {/* Active Client Selection Card */}
        <div className="bg-blue-50 border border-blue-200 p-3 rounded-2xl flex items-center gap-3">
          <div className="text-right">
            <span className="text-[10px] font-bold text-blue-700 uppercase tracking-wider block">
              Target Client
            </span>
            <select
              value={activeClient ? activeClient.id : ''}
              onChange={(e) => onSelectClient(e.target.value)}
              className="bg-transparent text-xs font-bold text-blue-900 focus:outline-none cursor-pointer"
            >
              <option value="" disabled>-- Select Client --</option>
              {clients.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} ({c.niche})
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Mandatory Empty State Banner when No Provider Configured */}
      {isNotConfigured && (
        <div className="p-6 bg-amber-50/90 border-2 border-amber-300 rounded-2xl space-y-3">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-6 h-6 text-amber-600 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <h3 className="text-base font-bold text-amber-900">
                {providerStatus.message}
              </h3>
              <p className="text-xs text-amber-800">
                Select a configured provider in Settings before searching.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 pt-2">
            <button
              onClick={onNavigateToSettings}
              className="flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold px-4 py-2 rounded-xl transition-colors shadow-xs"
            >
            <Settings className="w-4 h-4 text-white" /> Configure the selected provider in Settings
            </button>
          </div>
        </div>
      )}

      {!activeClient && (
        <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl flex items-center gap-3 text-amber-800 text-xs">
          <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0" />
          <span>
            Please select a target client above before running a lead search so all discovered leads remain isolated to that client.
          </span>
        </div>
      )}

      {/* Mode Selector Tabs */}
        <div className="flex bg-gray-100 p-1 rounded-2xl max-w-md gap-1">
          <button
            type="button"
            onClick={() => setSearchMode('manual')}
            className={`flex-1 py-2.5 px-4 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 ${
              searchMode === 'manual'
                ? 'bg-white text-blue-900 shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <Filter className="w-4 h-4 text-blue-600" />
            A. Manual Filters
          </button>
          <button
            type="button"
            onClick={() => setSearchMode('profile')}
            className={`flex-1 py-2.5 px-4 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 ${
              searchMode === 'profile'
                ? 'bg-white text-blue-900 shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <Link className="w-4 h-4 text-purple-600" />
            B. LinkedIn Profile Mode
          </button>
        </div>

      {/* PROFILE MODE VIEW */}
      {searchMode === 'profile' && (
        <div className="bg-white rounded-2xl border border-gray-200/90 shadow-xs p-6 space-y-6">
          <div className="space-y-1">
            <h2 className="text-base font-bold text-gray-900 flex items-center gap-2">
              <Link className="w-5 h-5 text-purple-600" /> LinkedIn Profile ICP Mode
            </h2>
            <p className="text-xs text-gray-500">
              Paste a client or reference LinkedIn profile URL. We will analyze the profile and generate a target Ideal Customer Profile (ICP) summary automatically.
            </p>
          </div>

          <div className="space-y-3">
            <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider">
              Client LinkedIn Profile URL *
            </label>
            <div className="flex gap-3">
              <div className="relative flex-1">
                <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-400">
                  <User className="w-4 h-4" />
                </span>
                <input
                  type="url"
                  placeholder="https://www.linkedin.com/in/example-profile"
                  value={clientProfileUrl}
                  onChange={(e) => setClientProfileUrl(e.target.value)}
                  className="w-full text-xs font-medium border border-gray-300 rounded-xl pl-10 pr-3.5 py-3 focus:outline-none focus:ring-2 focus:ring-purple-500/20 focus:border-purple-500"
                />
              </div>
              <button
                type="button"
                onClick={handleAnalyzeProfile}
                disabled={isAnalyzing || !clientProfileUrl.trim()}
                className="flex items-center gap-2 bg-purple-600 hover:bg-purple-700 disabled:opacity-50 text-white font-bold text-xs px-6 py-3 rounded-xl transition-all shadow-md shadow-purple-600/20 shrink-0"
              >
                {isAnalyzing ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Analyzing...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>Analyze Profile & ICP</span>
                  </>
                )}
              </button>
            </div>

            {profileInputError && (
              <p className="text-xs text-red-600 font-semibold flex items-center gap-1.5 mt-1">
                <XCircle className="w-4 h-4" /> {profileInputError}
              </p>
            )}
          </div>

          {/* Analyzed ICP Results Card */}
          {analyzedIcp && (
            <div className="p-6 bg-purple-50/70 border border-purple-200 rounded-2xl space-y-4 animate-fade-in">
              <div className="flex items-center gap-2 text-purple-900 font-bold text-sm">
                <Sparkles className="w-4 h-4 text-purple-600" />
                Generated Target ICP Summary from Profile
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs bg-white p-4 rounded-xl border border-purple-100">
                <div>
                  <span className="font-bold text-gray-500 uppercase block text-[10px] mb-1">Target Job Titles</span>
                  <div className="flex flex-wrap gap-1">
                    {analyzedIcp.jobTitles.map((t) => (
                      <span key={t} className="bg-blue-50 text-blue-800 px-2 py-0.5 rounded font-semibold border border-blue-200">
                        {t}
                      </span>
                    ))}
                  </div>
                </div>

                <div>
                  <span className="font-bold text-gray-500 uppercase block text-[10px] mb-1">Target Industry</span>
                  <div className="flex flex-wrap gap-1">
                    {analyzedIcp.industry.map((ind) => (
                      <span key={ind} className="bg-purple-50 text-purple-800 px-2 py-0.5 rounded font-semibold border border-purple-200">
                        {ind}
                      </span>
                    ))}
                  </div>
                </div>

                <div>
                  <span className="font-bold text-gray-500 uppercase block text-[10px] mb-1">Location</span>
                  <p className="font-semibold text-gray-900">
                    {analyzedIcp.city ? `${analyzedIcp.city}, ${analyzedIcp.country}` : analyzedIcp.country}
                  </p>
                </div>

                <div>
                  <span className="font-bold text-gray-500 uppercase block text-[10px] mb-1">Seniority & Company Size</span>
                  <p className="font-semibold text-gray-900">
                    {analyzedIcp.seniority.join(', ')} | Size: {analyzedIcp.companySize.join(', ')}
                  </p>
                </div>
              </div>

              <div className="flex items-center justify-between pt-2">
                <span className="text-[11px] text-purple-700 italic">
                  Ready to discover matching real B2B leads from Wikidata using this profile's ICP.
                </span>
                <button
                  type="button"
                  onClick={handleSearchWithAnalyzedIcp}
                  disabled={isSearching || !activeClient}
                  className="flex items-center gap-2 bg-purple-700 hover:bg-purple-800 text-white font-bold text-xs px-5 py-3 rounded-xl transition-all shadow-md shadow-purple-700/20"
                >
                  {isSearching ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Searching ICP Leads...</span>
                    </>
                  ) : (
                    <>
                      <Search className="w-4 h-4" />
                      <span>Run Search with Generated ICP</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* MANUAL FILTERS MODE VIEW */}
      {searchMode === 'manual' && (
        <div className="bg-white rounded-2xl border border-gray-200/90 shadow-xs p-6 space-y-6">
          
          {/* Section 1: Job Titles & Industry */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Job Titles */}
            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1.5">
                Job Titles * (Multiple Allowed)
              </label>
              <div className="flex gap-2 mb-2">
                <input
                  type="text"
                  placeholder="Type job title & press Enter..."
                  value={titleInput}
                  onChange={(e) => setTitleInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleAddJobTitle(titleInput);
                    }
                  }}
                  className="flex-1 text-xs border border-gray-300 rounded-xl px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                />
                <button
                  type="button"
                  onClick={() => handleAddJobTitle(titleInput)}
                  className="bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs font-semibold px-3 py-2 rounded-xl"
                >
                  Add
                </button>
              </div>



              {/* Selected Tags */}
              <div className="flex flex-wrap gap-1.5 min-h-[36px]">
                {jobTitles.map((title) => (
                  <span
                    key={title}
                    className="inline-flex items-center gap-1.5 bg-blue-50 text-blue-800 border border-blue-200 text-xs font-semibold px-2.5 py-1 rounded-lg"
                  >
                    {title}
                    <button
                      type="button"
                      onClick={() => handleRemoveJobTitle(title)}
                      className="text-blue-500 hover:text-blue-900 font-bold"
                    >
                      ×
                    </button>
                  </span>
                ))}
              </div>

              {/* Presets */}
              <div className="mt-2 text-[11px] text-gray-500 flex flex-wrap items-center gap-1">
                <span className="font-medium text-gray-400">Presets:</span>
                {POPULAR_JOB_TITLE_PRESETS.slice(0, 5).map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => handleAddJobTitle(preset)}
                    className="text-blue-600 hover:underline bg-gray-50 px-1.5 py-0.5 rounded border border-gray-200"
                  >
                    +{preset}
                  </button>
                ))}
              </div>
            </div>

            {/* Industry */}
            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1.5">
                Industry (Multiple Allowed)
              </label>
              <div className="flex gap-2 mb-2">
                <input
                  type="text"
                  placeholder="Type industry & press Enter..."
                  value={industryInput}
                  onChange={(e) => setIndustryInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleAddIndustry(industryInput);
                    }
                  }}
                  className="flex-1 text-xs border border-gray-300 rounded-xl px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                />
                <button
                  type="button"
                  onClick={() => handleAddIndustry(industryInput)}
                  className="bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs font-semibold px-3 py-2 rounded-xl"
                >
                  Add
                </button>
              </div>

              {/* Selected Industries */}
              <div className="flex flex-wrap gap-1.5 min-h-[36px]">
                {industries.map((ind) => (
                  <span
                    key={ind}
                    className="inline-flex items-center gap-1.5 bg-purple-50 text-purple-800 border border-purple-200 text-xs font-semibold px-2.5 py-1 rounded-lg"
                  >
                    {ind}
                    <button
                      type="button"
                      onClick={() => handleRemoveIndustry(ind)}
                      className="text-purple-500 hover:text-purple-900 font-bold"
                    >
                      ×
                    </button>
                  </span>
                ))}
              </div>

              {/* Presets */}
              <div className="mt-2 text-[11px] text-gray-500 flex flex-wrap items-center gap-1">
                <span className="font-medium text-gray-400">Presets:</span>
                {POPULAR_INDUSTRY_PRESETS.slice(0, 4).map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => handleAddIndustry(preset)}
                    className="text-purple-600 hover:underline bg-gray-50 px-1.5 py-0.5 rounded border border-gray-200"
                  >
                    +{preset}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Section 2: Country & City */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4 border-t border-gray-100">
            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1.5">
                Country *
              </label>
              <select
                value={country}
                onChange={(e) => setCountry(e.target.value)}
                className="w-full text-xs font-medium border border-gray-300 rounded-xl px-3.5 py-2.5 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
              >
                {POPULAR_COUNTRIES.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1.5">
                City (Optional)
              </label>
              <input
                type="text"
                placeholder="e.g. New York, Chicago, London, Toronto"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                className="w-full text-xs border border-gray-300 rounded-xl px-3.5 py-2.5 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
              />
            </div>
          </div>

          {/* Section 3: Seniority & Company Size */}
          <div className="space-y-4 pt-4 border-t border-gray-100">
            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-2">
                Seniority Level
              </label>
              <div className="flex flex-wrap gap-2">
                {SENIORITY_OPTIONS.map((level) => {
                  const isSelected = seniority.includes(level);
                  return (
                    <button
                      key={level}
                      type="button"
                      onClick={() => toggleSeniority(level)}
                      className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold border transition-all ${
                        isSelected
                          ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
                          : 'bg-white text-gray-600 border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      {level}
                    </button>
                  );
                })}
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-2">
                Company Size (Employees)
              </label>
              <div className="flex flex-wrap gap-2">
                {COMPANY_SIZE_OPTIONS.map((size) => {
                  const isSelected = companySize.includes(size);
                  return (
                    <button
                      key={size}
                      type="button"
                      onClick={() => toggleCompanySize(size)}
                      className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold border transition-all ${
                        isSelected
                          ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                          : 'bg-white text-gray-600 border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      {size}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Section 4: Max Leads Limit */}
          <div className="pt-4 border-t border-gray-100 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">
                  Maximum Leads to Discover (Max 500)
                </label>
                <p className="text-xs text-gray-500">Select batch size for search execution (Default: 50)</p>
              </div>
              <span className="text-sm font-bold text-blue-700 bg-blue-50 px-3 py-1 rounded-xl border border-blue-200">
                {maxLeads} Leads Selected
              </span>
            </div>
            <div className="flex flex-wrap gap-2">
              {[5, 50, 100, 200, 300, 500].map((num) => {
                const isSelected = maxLeads === num;
                return (
                  <button
                    key={num}
                    type="button"
                    onClick={() => setMaxLeads(num)}
                    className={`px-4 py-2 rounded-xl text-xs font-bold border transition-all ${
                      isSelected
                        ? 'bg-blue-600 text-white border-blue-600 shadow-sm shadow-blue-600/20'
                        : 'bg-white text-gray-700 border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                    }`}
                  >
                    {num} {num === 50 ? '(Default)' : ''}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Filter Summary Before Starting */}
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-2 text-xs">
            <div className="font-bold text-slate-800 flex items-center gap-2">
              <Filter className="w-3.5 h-3.5 text-blue-600" /> Filter Summary Overview
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2 text-slate-600">
              <div><span className="font-semibold text-slate-900">Client:</span> {activeClient?.name || 'None'}</div>
              <div><span className="font-semibold text-slate-900">Titles:</span> {jobTitles.join(', ') || 'Any'}</div>
              <div><span className="font-semibold text-slate-900">Location:</span> {city ? `${city}, ${country}` : country}</div>
              <div><span className="font-semibold text-slate-900">Seniority:</span> {seniority.join(', ') || 'Any'}</div>
            </div>
          </div>

          {searchError && (
            <div className="p-4 bg-red-50 border border-red-200 rounded-2xl text-xs text-red-700 font-medium flex items-start gap-2">
              <XCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold">Search Execution Error</p>
                <p className="mt-0.5">{searchError}</p>
              </div>
            </div>
          )}

          {/* Find Leads Action Button */}
          <div className="pt-2">
            <button
              onClick={() => handleRunSearch()}
              disabled={isSearching || !activeClient || isNotConfigured}
              className="w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-bold text-sm py-3.5 px-6 rounded-2xl transition-all shadow-md shadow-blue-600/20"
            >
              {isSearching ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span>Searching & Deduplicating...</span>
                </>
              ) : (
                <>
                  <Search className="w-5 h-5" />
                  <span>Find Leads</span>
                </>
              )}
            </button>
          </div>
        </div>
      )}

      {/* Real Progress Modal Overlay */}
      {isSearching && progressState && (
        <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl border border-gray-200 max-w-md w-full p-6 text-center space-y-4">
            <div className="w-14 h-14 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center mx-auto shadow-inner">
              <Loader2 className="w-7 h-7 animate-spin" />
            </div>

            <div>
              <h3 className="text-lg font-bold text-gray-900">{progressState.message}</h3>
              <p className="text-xs text-gray-500 mt-1">Executing server-side validation & deduplication pipeline</p>
            </div>

            {/* Step Progress Tracker */}
            <div className="space-y-2 text-left pt-2">
              {[
                'Preparing search parameters...',
                'Connecting to server lead provider...',
                'Validating public lead records...',
                'Deduplicating provider records...',
                'Saving unique leads to client database...'
              ].map((msg, idx) => {
                const stepNum = idx + 1;
                const isCompleted = progressState.step > stepNum;
                const isCurrent = progressState.step === stepNum;

                return (
                  <div key={msg} className="flex items-center gap-3 text-xs">
                    {isCompleted ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    ) : isCurrent ? (
                      <Loader2 className="w-4 h-4 text-blue-600 animate-spin shrink-0" />
                    ) : (
                      <div className="w-4 h-4 rounded-full border border-gray-300 shrink-0" />
                    )}
                    <span className={isCompleted ? 'text-gray-900 font-semibold' : isCurrent ? 'text-blue-600 font-bold' : 'text-gray-400'}>
                      {msg}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Completion Summary Card */}
      {searchResultSummary && (() => {
        const leads = searchResultSummary.uniqueLeads || [];
        const qualifiedCount = leads.filter((l) => l.b2bClassification === 'Qualified Prospect').length;
        const contactAvailableCount = leads.filter((l) => l.b2bClassification === 'Contact Available').length;
        const relevantCount = leads.filter((l) => l.b2bClassification === 'Relevant').length;
        const discoveredCount = leads.filter((l) => l.b2bClassification === 'Discovered' || !l.b2bClassification).length;
        const deceasedCount = leads.filter((l) => l.isDeceased).length;
        const modernCount = leads.filter((l) => !l.isDeceased && l.entityPeriod !== 'historical').length;
        const avgScore = leads.length > 0
          ? Math.round(leads.reduce((acc, l) => acc + (l.relevanceScore || 0), 0) / leads.length)
          : 0;

        return (
          <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-6 space-y-4">
            <div className="flex items-center gap-3">
              <CheckCircle2 className="w-7 h-7 text-emerald-600 shrink-0" />
              <div>
                <h3 className="text-lg font-bold text-emerald-900">
                  Search completed — {searchResultSummary.finalCount} unique leads found.
                </h3>
                <p className={`text-xs mt-0.5 ${searchResultSummary.persistenceStatus === 'confirmed' ? 'text-emerald-700' : 'text-amber-800'}`}>
                  {searchResultSummary.persistenceMessage}
                  {searchResultSummary.persistenceStatus === 'confirmed' && (
                    <> Client: <span className="font-bold">{activeClient?.name}</span>.</>
                  )}
                </p>
              </div>
            </div>

            {/* Pipeline Volume Stats */}
            <div className="grid grid-cols-3 gap-3 text-center bg-white/80 p-3 rounded-xl border border-emerald-100">
              <div>
                <p className="text-[10px] text-gray-500 font-semibold uppercase">Candidates Discovered</p>
                <p className="text-base font-bold text-gray-900">{searchResultSummary.candidatesFound}</p>
              </div>
              <div>
                <p className="text-[10px] text-amber-700 font-semibold uppercase">Duplicates Removed</p>
                <p className="text-base font-bold text-amber-600">-{searchResultSummary.duplicatesRemoved}</p>
              </div>
              <div>
                <p className="text-[10px] text-emerald-700 font-semibold uppercase">Final Unique Leads</p>
                <p className="text-base font-bold text-emerald-700">{searchResultSummary.finalCount}</p>
              </div>
            </div>

            {/* B2B Prospect Intelligence Breakdown */}
            {leads.length > 0 && (
              <div className="bg-white/90 rounded-xl p-4 border border-emerald-200/60 space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-gray-100 pb-2">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    <span className="text-xs font-bold text-gray-900">B2B Lead Status Classification</span>
                  </div>
                  <span className="text-[11px] font-semibold text-emerald-800 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
                    Avg Relevance Score: {avgScore}/100
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-xs">
                  <div className="p-2.5 rounded-lg bg-emerald-50/70 border border-emerald-200">
                    <p className="text-[10px] uppercase font-bold text-emerald-800">Qualified Prospects</p>
                    <p className="text-sm font-extrabold text-emerald-700 mt-0.5">{qualifiedCount}</p>
                    <p className="text-[9px] text-gray-500 mt-0.5">High fit + website</p>
                  </div>
                  <div className="p-2.5 rounded-lg bg-blue-50/70 border border-blue-200">
                    <p className="text-[10px] uppercase font-bold text-blue-800">Contact Available</p>
                    <p className="text-sm font-extrabold text-blue-700 mt-0.5">{contactAvailableCount}</p>
                    <p className="text-[9px] text-gray-500 mt-0.5">Website on record</p>
                  </div>
                  <div className="p-2.5 rounded-lg bg-purple-50/70 border border-purple-200">
                    <p className="text-[10px] uppercase font-bold text-purple-800">Relevant</p>
                    <p className="text-sm font-extrabold text-purple-700 mt-0.5">{relevantCount}</p>
                    <p className="text-[9px] text-gray-500 mt-0.5">Role matches search</p>
                  </div>
                  <div className="p-2.5 rounded-lg bg-gray-50/80 border border-gray-200">
                    <p className="text-[10px] uppercase font-bold text-gray-700">Discovered</p>
                    <p className="text-sm font-extrabold text-gray-700 mt-0.5">{discoveredCount}</p>
                    <p className="text-[9px] text-gray-500 mt-0.5">Genuine entity</p>
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-between text-[11px] text-gray-600 pt-1">
                  <div className="flex items-center gap-3">
                    <span>
                      Modern / Contemporary: <span className="font-bold text-gray-900">{modernCount}</span>
                    </span>
                    {deceasedCount > 0 && (
                      <span className="text-amber-800 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                        Historical / Deceased Identified: <span className="font-bold">{deceasedCount}</span>
                      </span>
                    )}
                  </div>
                  <span className="text-[10px] text-gray-500 italic">
                    Missing data is not treated as negative proof.
                  </span>
                </div>
              </div>
            )}

            <div className="flex justify-end pt-2">
              <button
                onClick={onNavigateToLeads}
                className="flex items-center gap-2 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold px-4 py-2.5 rounded-xl transition-all shadow-xs"
              >
                View Discovered Leads <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        );
      })()}
    </div>
  );
};
