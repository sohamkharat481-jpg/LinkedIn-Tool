var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res, err) => function __init() {
  if (err) throw err[0];
  try {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  } catch (e) {
    throw err = [e], e;
  }
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// src/server/instagramDiscoveryService.ts
var instagramDiscoveryService_exports = {};
__export(instagramDiscoveryService_exports, {
  InstagramDiscoveryService: () => InstagramDiscoveryService
});
var RESERVED_INSTAGRAM_PATHS, InstagramDiscoveryService;
var init_instagramDiscoveryService = __esm({
  "src/server/instagramDiscoveryService.ts"() {
    RESERVED_INSTAGRAM_PATHS = /* @__PURE__ */ new Set([
      "p",
      "reel",
      "reels",
      "stories",
      "explore",
      "accounts",
      "developer",
      "legal",
      "about",
      "directory",
      "channel",
      "tv",
      "tags",
      "login",
      "share",
      "help",
      "privacy",
      "terms",
      "api",
      "graphql",
      "create",
      "direct"
    ]);
    InstagramDiscoveryService = class {
      /**
       * Discovers and verifies the public Instagram profile and contact info for a single business lead
       * using deep website page crawling (homepage + /contact, /about, /team).
       */
      static async discoverForLead(target) {
        const checkedAt = (/* @__PURE__ */ new Date()).toISOString();
        if (target.profileUrl) {
          const qidMatch = target.profileUrl.match(/Q\d+/i);
          if (qidMatch) {
            const qid = qidMatch[0].toUpperCase();
            try {
              const wikidataResult = await this.queryWikidataP2003(qid, target.fullName);
              if (wikidataResult) {
                console.log(`[Diagnostic] Wikidata P2003 discovered for "${target.fullName}" (${qid}): @${wikidataResult.username}`);
                let siteEmail;
                let sitePhone;
                if (target.businessWebsite && /^https?:\/\//i.test(target.businessWebsite.trim())) {
                  try {
                    const siteInspection = await this.inspectWebsiteDeep(target.businessWebsite.trim());
                    siteEmail = siteInspection.email;
                    sitePhone = siteInspection.phone;
                  } catch {
                  }
                }
                return {
                  instagramUsername: wikidataResult.username,
                  instagramProfileUrl: `https://www.instagram.com/${wikidataResult.username}/`,
                  instagramVerificationStatus: "Verified",
                  instagramVerificationEvidence: `Verified via official Wikidata entity statement (P2003) linked to ${target.fullName} (${qid})`,
                  instagramDiscoverySource: "Wikidata (P2003)",
                  instagramLastCheckedAt: checkedAt,
                  discoveredEmail: siteEmail,
                  discoveredPhone: sitePhone
                };
              }
            } catch (err) {
              console.warn(`[Diagnostic] Wikidata Instagram lookup warning for ${qid}:`, err.message || err);
            }
          }
        }
        if (target.businessWebsite && /^https?:\/\//i.test(target.businessWebsite.trim())) {
          const websiteUrl = target.businessWebsite.trim();
          const inspection = await this.inspectWebsiteDeep(websiteUrl);
          if (inspection.fetchError && !inspection.email && !inspection.phone && !inspection.username) {
            console.log(`[Diagnostic] Website inspection error for "${target.fullName}" (${websiteUrl}): ${inspection.fetchError}`);
            return {
              instagramUsername: void 0,
              instagramProfileUrl: void 0,
              instagramVerificationStatus: "Lookup Failed",
              instagramVerificationEvidence: `Website lookup failed (${inspection.fetchError}) inspecting official website (${websiteUrl})`,
              instagramDiscoverySource: "Official Business Website Inspection",
              instagramLastCheckedAt: checkedAt,
              discoveredEmail: inspection.email,
              discoveredPhone: inspection.phone
            };
          }
          if (inspection.username) {
            console.log(`[Diagnostic] Official website Instagram link verified for "${target.fullName}": @${inspection.username} via ${inspection.sourcePageUrl || websiteUrl}`);
            return {
              instagramUsername: inspection.username,
              instagramProfileUrl: `https://www.instagram.com/${inspection.username}/`,
              instagramVerificationStatus: "Verified",
              instagramVerificationEvidence: `Verified via official link discovered on business page (${inspection.sourcePageUrl || websiteUrl})`,
              instagramDiscoverySource: "Official Business Website",
              instagramLastCheckedAt: checkedAt,
              discoveredEmail: inspection.email,
              discoveredPhone: inspection.phone
            };
          }
          if (inspection.email || inspection.phone) {
            return {
              instagramUsername: void 0,
              instagramProfileUrl: void 0,
              instagramVerificationStatus: "Not Found",
              instagramVerificationEvidence: `Contact details extracted from official website (${inspection.sourcePageUrl || websiteUrl}), but no Instagram profile found`,
              instagramDiscoverySource: "Official Business Website Inspection",
              instagramLastCheckedAt: checkedAt,
              discoveredEmail: inspection.email,
              discoveredPhone: inspection.phone
            };
          }
          return {
            instagramUsername: void 0,
            instagramProfileUrl: void 0,
            instagramVerificationStatus: "Not Found",
            instagramVerificationEvidence: `No public Instagram business link or contact info found on inspected official website (${websiteUrl}) or in Wikidata records for "${target.fullName}"`,
            instagramDiscoverySource: "Official Business Website Inspection",
            instagramLastCheckedAt: checkedAt,
            discoveredEmail: inspection.email,
            discoveredPhone: inspection.phone
          };
        }
        if (target.currentUsername && /^[a-zA-Z0-9._]{1,30}$/.test(target.currentUsername.replace(/^@/, ""))) {
          const cleanHandle = target.currentUsername.replace(/^@/, "").trim();
          return {
            instagramUsername: cleanHandle,
            instagramProfileUrl: `https://www.instagram.com/${cleanHandle}/`,
            instagramVerificationStatus: "Needs Review",
            instagramVerificationEvidence: `Candidate handle @${cleanHandle} provided for manual review before outreach`,
            instagramDiscoverySource: "Manual / Candidate Suggestion",
            instagramLastCheckedAt: checkedAt
          };
        }
        return {
          instagramUsername: void 0,
          instagramProfileUrl: void 0,
          instagramVerificationStatus: "Not Found",
          instagramVerificationEvidence: `No public Instagram business profile found in Wikidata records or on official website for "${target.fullName}"`,
          instagramDiscoverySource: "Inspection Engine",
          instagramLastCheckedAt: checkedAt
        };
      }
      /**
       * Batch discovers Instagram profiles for an array of leads with rate-limit and concurrency control.
       */
      static async discoverBatch(targets) {
        const results = {};
        const limit = Math.min(targets.length, 30);
        const chunkSize = 4;
        for (let i = 0; i < limit; i += chunkSize) {
          const chunk = targets.slice(i, i + chunkSize);
          await Promise.all(
            chunk.map(async (target) => {
              const key = target.leadId || target.profileUrl || target.fullName;
              try {
                results[key] = await this.discoverForLead(target);
              } catch (err) {
                results[key] = {
                  instagramVerificationStatus: "Lookup Failed",
                  instagramVerificationEvidence: `Discovery process encountered error: ${err.message || "Unknown network error"}`,
                  instagramDiscoverySource: "Inspection Engine",
                  instagramLastCheckedAt: (/* @__PURE__ */ new Date()).toISOString()
                };
              }
            })
          );
        }
        return results;
      }
      /**
       * SPARQL query specifically for P2003 on a given Wikidata entity QID
       */
      static async queryWikidataP2003(qid, fullName) {
        const sparql = `
      SELECT ?instagram WHERE {
        wd:${qid} wdt:P2003 ?instagram .
      } LIMIT 1
    `;
        const url = `https://query.wikidata.org/sparql?query=${encodeURIComponent(sparql)}&format=json`;
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 6e3);
        try {
          const res = await fetch(url, {
            headers: {
              "Accept": "application/sparql-results+json",
              "User-Agent": "LinkedInLeadFinder/1.0 (https://github.com/leadfinder; mailto:contact@example.com)"
            },
            signal: controller.signal
          });
          clearTimeout(timer);
          if (!res.ok) return null;
          const data = await res.json();
          const bindings = data?.results?.bindings;
          if (Array.isArray(bindings) && bindings.length > 0) {
            const val = bindings[0].instagram?.value;
            if (val) {
              const clean = val.trim().replace(/^@/, "");
              if (/^[a-zA-Z0-9._]{1,30}$/.test(clean)) {
                return { username: clean };
              }
            }
          }
          return null;
        } catch {
          clearTimeout(timer);
          return null;
        }
      }
      /**
       * Deep website inspection: Scrapes homepage, discovers contact/about/team links, and inspects them (up to 4 pages max).
       */
      static async inspectWebsiteDeep(websiteUrl) {
        const normalizedRoot = this.sanitizeAndNormalizeUrl(websiteUrl);
        if (!normalizedRoot) {
          return { fetchError: "Invalid or unsafe website URL" };
        }
        const visitedUrls = /* @__PURE__ */ new Set();
        const urlsToVisit = [normalizedRoot];
        let bestUsername;
        let bestEmail;
        let bestPhone;
        let sourcePageUrl;
        let lastError;
        const maxPages = 4;
        let pagesInspected = 0;
        while (urlsToVisit.length > 0 && pagesInspected < maxPages) {
          const currentUrl = urlsToVisit.shift();
          if (visitedUrls.has(currentUrl)) continue;
          visitedUrls.add(currentUrl);
          pagesInspected++;
          const pageResult = await this.fetchAndParsePage(currentUrl);
          if (pageResult.fetchError) {
            lastError = pageResult.fetchError;
            continue;
          }
          if (pageResult.username && !bestUsername) {
            bestUsername = pageResult.username;
            sourcePageUrl = currentUrl;
          }
          if (pageResult.email && !bestEmail) {
            bestEmail = pageResult.email;
            sourcePageUrl = sourcePageUrl || currentUrl;
          }
          if (pageResult.phone && !bestPhone) {
            bestPhone = pageResult.phone;
            sourcePageUrl = sourcePageUrl || currentUrl;
          }
          if (bestUsername && bestEmail && bestPhone) break;
          if (currentUrl === normalizedRoot && pageResult.html) {
            const discoveredLinks = this.extractContactSubpageLinks(pageResult.html, normalizedRoot);
            for (const link of discoveredLinks) {
              if (!visitedUrls.has(link) && !urlsToVisit.includes(link) && urlsToVisit.length < 5) {
                urlsToVisit.push(link);
              }
            }
          }
        }
        if (!bestUsername && !bestEmail && !bestPhone && lastError) {
          return { fetchError: lastError };
        }
        return {
          username: bestUsername,
          email: bestEmail,
          phone: bestPhone,
          sourcePageUrl
        };
      }
      /**
       * Safe URL sanitizer & SSRF prevention validator
       */
      static sanitizeAndNormalizeUrl(rawUrl) {
        if (!rawUrl || typeof rawUrl !== "string") return null;
        let trimmed = rawUrl.trim();
        if (!/^https?:\/\//i.test(trimmed)) {
          trimmed = `https://${trimmed}`;
        }
        try {
          const parsed = new URL(trimmed);
          const hostname = parsed.hostname.toLowerCase();
          if (parsed.protocol !== "http:" && parsed.protocol !== "https:") return null;
          if (hostname === "localhost" || hostname === "127.0.0.1" || hostname === "0.0.0.0" || hostname.startsWith("10.") || hostname.startsWith("192.168.") || hostname.endsWith(".local") || hostname.endsWith(".internal")) {
            return null;
          }
          return parsed.toString();
        } catch {
          return null;
        }
      }
      /**
       * Fetches a single page with strict timeout, size limit, and HTML validation
       */
      static async fetchAndParsePage(url) {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 6e3);
        try {
          const response = await fetch(url, {
            headers: {
              "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 (compatible; LeadFinder/1.0)",
              "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
            },
            redirect: "follow",
            signal: controller.signal
          });
          clearTimeout(timer);
          if (!response.ok) {
            return { fetchError: `HTTP status ${response.status} ${response.statusText}` };
          }
          const contentType = response.headers.get("content-type") || "";
          if (!contentType.includes("text/html") && !contentType.includes("text/plain")) {
            return { fetchError: `Non-HTML content type (${contentType})` };
          }
          const textBuffer = await response.text();
          const html = textBuffer.length > 1024 * 1024 ? textBuffer.substring(0, 1024 * 1024) : textBuffer;
          const instaResult = this.parseInstagramUsernameFromHtml(html);
          const emailResult = this.parseEmailFromHtml(html);
          const phoneResult = this.parsePhoneFromHtml(html);
          return {
            username: instaResult?.username,
            email: emailResult,
            phone: phoneResult,
            html
          };
        } catch (err) {
          clearTimeout(timer);
          const msg = err.name === "AbortError" ? "Connection timed out after 6000ms" : err.message || "Network connection failed";
          return { fetchError: msg };
        }
      }
      /**
       * Extracts relevant same-domain contact/about/team subpage links from HTML
       */
      static extractContactSubpageLinks(html, rootUrl) {
        if (!html || typeof html !== "string") return [];
        const rootParsed = new URL(rootUrl);
        const links = [];
        const regex = /href=["']([^"'#\s]+)["']/gi;
        let match;
        const keywords = ["contact", "about", "team", "leadership", "reach", "staff", "office"];
        while ((match = regex.exec(html)) !== null) {
          const href = match[1];
          try {
            const absoluteUrl = new URL(href, rootUrl);
            if (absoluteUrl.hostname.toLowerCase() === rootParsed.hostname.toLowerCase()) {
              const pathLower = absoluteUrl.pathname.toLowerCase();
              if (keywords.some((kw) => pathLower.includes(kw))) {
                const clean = absoluteUrl.toString();
                if (!links.includes(clean) && clean !== rootUrl) {
                  links.push(clean);
                }
              }
            }
          } catch {
          }
        }
        return links;
      }
      /**
       * Backward-compatible alias for previous inspectWebsite tests
       */
      static async inspectWebsite(websiteUrl, fullName) {
        return this.inspectWebsiteDeep(websiteUrl);
      }
      /**
       * Backward-compatible alias for previous extractFromWebsite tests
       */
      static async extractFromWebsite(websiteUrl, fullName) {
        const res = await this.inspectWebsiteDeep(websiteUrl);
        return res.username ? { username: res.username } : null;
      }
      /**
       * Pure parsing function to extract genuine Instagram handles from HTML text.
       */
      static parseInstagramUsernameFromHtml(html) {
        if (!html || typeof html !== "string") return null;
        const regex = /(?:href=["'])?(?:https?:)?\/\/(?:www\.)?instagram\.com\/([a-zA-Z0-9._]{2,30})\/?["'/\s?#]/gi;
        let match;
        while ((match = regex.exec(html)) !== null) {
          const handle = match[1]?.trim().replace(/^@/, "");
          if (!handle) continue;
          const lower = handle.toLowerCase();
          if (RESERVED_INSTAGRAM_PATHS.has(lower)) continue;
          if (lower.endsWith(".png") || lower.endsWith(".jpg") || lower.endsWith(".js") || lower.endsWith(".css") || lower.endsWith(".svg")) continue;
          return { username: handle };
        }
        return null;
      }
      /**
       * Parses authentic public email from mailto: links or visible text patterns in HTML
       */
      static parseEmailFromHtml(html) {
        if (!html || typeof html !== "string") return void 0;
        const mailtoRegex = /href=["']mailto:([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})["'?]/gi;
        let match;
        while ((match = mailtoRegex.exec(html)) !== null) {
          const email = match[1]?.trim().toLowerCase();
          if (!email) continue;
          if (this.isInvalidOrPlaceholderEmail(email)) continue;
          return email;
        }
        const textEmailRegex = /\b[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}\b/g;
        const matches = html.match(textEmailRegex);
        if (matches) {
          for (const m of matches) {
            const clean = m.toLowerCase().trim();
            if (!this.isInvalidOrPlaceholderEmail(clean)) {
              return clean;
            }
          }
        }
        return void 0;
      }
      static isInvalidOrPlaceholderEmail(email) {
        if (email.includes("example.com") || email.includes("wixpress.com") || email.includes("sentry.io") || email.includes("domain.com") || email.includes("yourname") || email.includes("email.com") || email.endsWith(".png") || email.endsWith(".jpg") || email.endsWith(".js") || email.endsWith(".css")) {
          return true;
        }
        return false;
      }
      /**
       * Parses authentic public phone from tel: links or visible text patterns in HTML
       */
      static parsePhoneFromHtml(html) {
        if (!html || typeof html !== "string") return void 0;
        const telRegex = /href=["']tel:([+0-9\s().-]{7,25})["']/gi;
        let match;
        while ((match = telRegex.exec(html)) !== null) {
          const phone = match[1]?.trim();
          if (!phone) continue;
          const digitsOnly = phone.replace(/\D/g, "");
          if (digitsOnly.length >= 7 && digitsOnly.length <= 15 && (/[\s().-]/.test(phone) || phone.startsWith("+"))) {
            return phone;
          }
        }
        const visiblePhoneRegex = /(?:\+?[1-9]\d{0,2}[-.\s]?)?(?:\(\d{3}\)|\d{3})[-.\s]\d{3}[-.\s]\d{4}/g;
        const matches = html.match(visiblePhoneRegex);
        if (matches) {
          for (const m of matches) {
            const clean = m.trim();
            const digits = clean.replace(/\D/g, "");
            if (digits.length >= 10 && digits.length <= 15) {
              return clean;
            }
          }
        }
        return void 0;
      }
    };
  }
});

// src/server/lambda.ts
import express3 from "express";

// src/server/apiHandler.ts
import express2 from "express";

// src/services/deduplication.ts
function normalizeLinkedInUrl(url) {
  if (!url || typeof url !== "string") return "";
  let trimmed = url.trim().toLowerCase();
  if (!trimmed.startsWith("http://") && !trimmed.startsWith("https://")) {
    trimmed = "https://" + trimmed;
  }
  try {
    const parsed = new URL(trimmed);
    let hostname = parsed.hostname.replace(/^www\./, "");
    if (!hostname.includes("linkedin.com")) {
      return trimmed;
    }
    let pathname = parsed.pathname.replace(/\/+$/, "");
    return `https://${hostname}${pathname}`;
  } catch {
    return trimmed.split("?")[0].replace(/\/+$/, "");
  }
}
function normalizeProfileUrl(url) {
  if (!url || typeof url !== "string") return "";
  const trimmed = url.trim();
  try {
    const parsed = new URL(trimmed);
    const hostname = parsed.hostname.replace(/^www\./, "");
    if (hostname.includes("wikidata.org")) {
      const match = parsed.pathname.match(/\/(wiki|entity)\/(Q\d+)/i);
      if (match) {
        return `https://www.wikidata.org/wiki/${match[2].toUpperCase()}`;
      }
      return `https://${hostname}${parsed.pathname}`;
    }
    if (hostname === "linkedin.com") {
      return normalizeLinkedInUrl(url);
    }
    return trimmed;
  } catch {
    return trimmed;
  }
}
function generatePersonCompositeKey(lead) {
  const normName = (lead.fullName || "").toLowerCase().replace(/[^a-z0-9]/g, "");
  const normCompany = (lead.companyName || "").toLowerCase().replace(/[^a-z0-9]/g, "");
  const normUrl = normalizeProfileUrl(lead.profileUrl);
  return `${normName}_${normCompany}_${normUrl}`;
}
function isValidLeadRecord(lead) {
  if (!lead) return false;
  const isPresent = (value) => Boolean(value?.trim() && !["n/a", "na", "unknown"].includes(value.trim().toLowerCase()));
  const hasName = Boolean(isPresent(lead.fullName) && lead.fullName.trim().length >= 2);
  const hasJobTitle = Boolean(isPresent(lead.currentJobTitle) && lead.currentJobTitle.trim().length >= 2);
  const rawUrl = (lead.profileUrl || "").trim().toLowerCase();
  const hasValidUrl = Boolean(
    rawUrl && (rawUrl.includes("wikidata.org") || rawUrl.includes("linkedin.com") || rawUrl.startsWith("http://") || rawUrl.startsWith("https://"))
  );
  const hasCompanyOrSource = Boolean(
    lead.companyName && lead.companyName.trim().length >= 2 || lead.source?.includes("Wikidata")
  );
  return hasName && hasJobTitle && hasValidUrl && hasCompanyOrSource;
}
function filterAndDeduplicateLeads(candidates) {
  const rawCandidatesCount = candidates.length;
  const validRecords = candidates.filter(isValidLeadRecord);
  const validRecordsCount = validRecords.length;
  const uniqueUrlLeadsMap = /* @__PURE__ */ new Map();
  let duplicateProfilesRemoved = 0;
  let duplicateBusinessesRemoved = 0;
  for (const rawLead of validRecords) {
    const normalizedUrl = normalizeProfileUrl(rawLead.profileUrl);
    const normalizedLead = {
      ...rawLead,
      profileUrl: normalizedUrl
    };
    if (uniqueUrlLeadsMap.has(normalizedUrl)) {
      if (rawLead.leadType === "business") duplicateBusinessesRemoved++;
      else duplicateProfilesRemoved++;
    } else {
      uniqueUrlLeadsMap.set(normalizedUrl, normalizedLead);
    }
  }
  const uniquePeopleMap = /* @__PURE__ */ new Map();
  let duplicatePeopleRemoved = 0;
  for (const lead of uniqueUrlLeadsMap.values()) {
    const compositeKey = generatePersonCompositeKey(lead);
    if (uniquePeopleMap.has(compositeKey)) {
      duplicatePeopleRemoved++;
    } else {
      uniquePeopleMap.set(compositeKey, lead);
    }
  }
  const finalUniqueLeads = Array.from(uniquePeopleMap.values());
  const totalDuplicatesRemoved = duplicateProfilesRemoved + duplicatePeopleRemoved;
  return {
    rawCandidatesCount,
    validRecordsCount,
    duplicateProfilesRemoved,
    duplicatePeopleRemoved,
    duplicateBusinessesRemoved,
    totalDuplicatesRemoved,
    finalUniqueLeads
  };
}

// src/services/b2bRelevanceService.ts
function detectHistoricalStatus(dateOfDeath, dateOfBirth, description = "", headline = "") {
  const combinedText = `${description} ${headline}`.trim();
  if (dateOfDeath && dateOfDeath.trim().length > 0) {
    const yearMatch = dateOfDeath.match(/^([+-]?\d{1,4})/);
    const deathYear = yearMatch ? yearMatch[1].replace("+", "") : dateOfDeath.substring(0, 4);
    return {
      isDeceased: true,
      dateOfDeath: deathYear,
      dateOfBirth: dateOfBirth ? dateOfBirth.substring(0, 4).replace("+", "") : void 0,
      entityPeriod: "deceased",
      reason: `Documented date of death on Wikidata (${deathYear})`
    };
  }
  const lifetimeRegex = /\((\d{3,4})[\s–\-]+(\d{3,4})\)/;
  const match = combinedText.match(lifetimeRegex);
  if (match) {
    const birthYear = parseInt(match[1], 10);
    const deathYear = parseInt(match[2], 10);
    const currentYear = (/* @__PURE__ */ new Date()).getFullYear();
    if (deathYear <= currentYear) {
      return {
        isDeceased: true,
        dateOfDeath: String(deathYear),
        dateOfBirth: String(birthYear),
        entityPeriod: "deceased",
        reason: `Documented lifetime years in public description (${birthYear}\u2013${deathYear})`
      };
    }
  }
  if (/\b(died|deceased|late entrepreneur|late founder)\b/i.test(combinedText)) {
    return {
      isDeceased: true,
      entityPeriod: "deceased",
      reason: "Described as deceased in public record"
    };
  }
  if (dateOfBirth) {
    const yearMatch = dateOfBirth.match(/^([+-]?\d{1,4})/);
    const birthYear = yearMatch ? parseInt(yearMatch[1].replace("+", ""), 10) : NaN;
    if (!isNaN(birthYear)) {
      if (birthYear < 1925) {
        return {
          isDeceased: false,
          dateOfBirth: String(birthYear),
          entityPeriod: "historical",
          reason: `Historical era entity born in ${birthYear}`
        };
      }
      return {
        isDeceased: false,
        dateOfBirth: String(birthYear),
        entityPeriod: "modern",
        reason: `Modern era individual (born ${birthYear})`
      };
    }
  }
  if (/\b(18th-century|19th-century|ancient|historical figure)\b/i.test(combinedText)) {
    return {
      isDeceased: false,
      entityPeriod: "historical",
      reason: "Entity described as historical figure in public record"
    };
  }
  return {
    isDeceased: false,
    entityPeriod: "modern",
    reason: "Contemporary public record with no death date recorded"
  };
}
function calculateRelevanceScore(lead, filters, clientNiche) {
  const details = [];
  let occupationPoints = 0;
  let occupationMatch = false;
  const searchTitles = (filters.jobTitles || []).map((t) => t.toLowerCase().trim()).filter(Boolean);
  const headlineLower = (lead.headline || "").toLowerCase();
  const currentTitleLower = (lead.currentJobTitle || "").toLowerCase();
  let matchedTitle = "";
  for (const st of searchTitles) {
    if (headlineLower.includes(st) || currentTitleLower.includes(st)) {
      matchedTitle = st;
      break;
    }
  }
  if (matchedTitle) {
    occupationPoints = 35;
    occupationMatch = true;
    details.push(`Occupation (+35): Documented role directly matches requested title '${matchedTitle}'`);
  } else {
    let semanticMatched = "";
    for (const st of searchTitles) {
      if (st.includes("founder") || st.includes("company founder")) {
        if (/\b(entrepreneur|co-founder|owner|startup)\b/.test(headlineLower) || /\b(entrepreneur|co-founder|owner|startup)\b/.test(currentTitleLower)) {
          semanticMatched = "entrepreneur / co-founder";
          break;
        }
      } else if (st.includes("consultant")) {
        if (/\b(advisor|adviser|consultancy)\b/.test(headlineLower) || /\b(advisor|adviser|consultancy)\b/.test(currentTitleLower)) {
          semanticMatched = "advisor / consultant";
          break;
        }
      } else if (st.includes("coach")) {
        if (/\b(mentor|trainer)\b/.test(headlineLower) || /\b(mentor|trainer)\b/.test(currentTitleLower)) {
          semanticMatched = "coach / mentor";
          break;
        }
      }
    }
    if (semanticMatched) {
      occupationPoints = 25;
      occupationMatch = true;
      details.push(`Occupation (+25): Documented role semantically matches requested category (${semanticMatched})`);
    } else {
      occupationPoints = 0;
      occupationMatch = false;
      details.push("Occupation (+0): Documented role does not match requested occupation");
    }
  }
  let nichePoints = 0;
  let nicheMatch = false;
  const targetNiches = [];
  if (clientNiche && clientNiche.trim()) targetNiches.push(clientNiche.toLowerCase().trim());
  if (filters.industry && filters.industry.length > 0) {
    filters.industry.forEach((ind) => targetNiches.push(ind.toLowerCase().trim()));
  }
  if (targetNiches.length > 0) {
    const matchedNiche = targetNiches.find((niche) => {
      const terms = niche.split(/[\s,&/]+/).filter((t) => t.length > 2);
      return terms.some((term) => headlineLower.includes(term));
    });
    if (matchedNiche) {
      nichePoints = 25;
      nicheMatch = true;
      details.push(`Niche (+25): Documented background matches '${matchedNiche}'`);
    } else {
      nichePoints = 0;
      nicheMatch = false;
      details.push("Niche (+0): No explicit niche keywords documented (missing data not penalized)");
    }
  } else {
    nichePoints = 20;
    nicheMatch = true;
    details.push("Niche (+20 neutral): No specific industry or niche filter requested");
  }
  let websitePoints = 0;
  let websiteAvailable = false;
  if (lead.businessWebsite && /^https?:\/\//i.test(lead.businessWebsite.trim())) {
    websitePoints = 25;
    websiteAvailable = true;
    details.push(`Website (+25): Official verified website available in public record (${lead.businessWebsite})`);
  } else {
    websitePoints = 0;
    websiteAvailable = false;
    details.push("Website (+0): No official website documented in Wikidata (missing data not penalized)");
  }
  let activityPoints = 0;
  let activeEvidence;
  if (lead.isDeceased) {
    activityPoints = 0;
    activeEvidence = "Documented as deceased in public record";
    details.push("Activity (+0): Entity is documented as deceased");
  } else if (lead.entityPeriod === "historical") {
    activityPoints = 0;
    activeEvidence = "Pre-modern historical entity";
    details.push("Activity (+0): Pre-modern historical entity");
  } else if (websiteAvailable) {
    activityPoints = 15;
    activeEvidence = "Active contemporary web domain present in Wikidata record";
    details.push("Activity (+15): Contemporary entity with active verified web presence");
  } else {
    activityPoints = 5;
    activeEvidence = "Contemporary living entity; active status unconfirmed without direct website";
    details.push("Activity (+5): Contemporary living individual; current day-to-day activity unconfirmed");
  }
  let score = Math.min(Math.max(occupationPoints + nichePoints + websitePoints + activityPoints, 0), 100);
  if (!occupationMatch) {
    score = Math.min(score, 45);
  }
  const breakdown = {
    occupationMatch,
    occupationPoints,
    nicheMatch,
    nichePoints,
    websiteAvailable,
    websitePoints,
    activityEvidence: activityPoints > 0,
    activityPoints,
    details
  };
  const explanation = `Score ${score}/100: ${details.join(". ")}.`;
  let classification = "Discovered";
  if (lead.isDeceased || lead.entityPeriod === "historical" || score < 40 || !occupationMatch) {
    classification = "Discovered";
  } else if (!websiteAvailable) {
    classification = "Relevant";
  } else if (score >= 70 && occupationPoints >= 25) {
    classification = "Qualified Prospect";
  } else {
    classification = "Contact Available";
  }
  return {
    score,
    breakdown,
    explanation,
    classification,
    activeEvidence
  };
}
function enrichRawLead(raw, filters, clientNiche, rawDateOfDeath, rawDateOfBirth) {
  const historical = detectHistoricalStatus(
    rawDateOfDeath || raw.dateOfDeath,
    rawDateOfBirth || raw.dateOfBirth,
    raw.headline,
    raw.currentJobTitle
  );
  const relevance = calculateRelevanceScore(
    {
      fullName: raw.fullName,
      headline: raw.headline,
      currentJobTitle: raw.currentJobTitle,
      businessWebsite: raw.businessWebsite,
      isDeceased: historical.isDeceased,
      entityPeriod: historical.entityPeriod
    },
    filters,
    clientNiche
  );
  return {
    ...raw,
    isDeceased: historical.isDeceased,
    dateOfDeath: historical.dateOfDeath,
    dateOfBirth: historical.dateOfBirth,
    entityPeriod: historical.entityPeriod,
    relevanceScore: relevance.score,
    relevanceExplanation: relevance.explanation,
    relevanceBreakdown: relevance.breakdown,
    b2bClassification: relevance.classification,
    activeEvidence: relevance.activeEvidence
  };
}

// src/services/leadProviders/WikidataLeadProvider.ts
var SOURCE_NAME = "Wikidata SPARQL Query Service";
var DEFAULT_TIMEOUT_MS = 15e3;
var OCCUPATION_MAP = {
  "consultant": ["wd:Q15978655"],
  "management consultant": ["wd:Q15978655"],
  "strategy consultant": ["wd:Q15978655"],
  "adviser": ["wd:Q15978655"],
  "advisor": ["wd:Q15978655"],
  "business coach": ["wd:Q105201291", "wd:Q2790938", "wd:Q26831130"],
  "executive coach": ["wd:Q2790938", "wd:Q105201291"],
  "coach": ["wd:Q105201291", "wd:Q2790938", "wd:Q26831130"],
  "life coach": ["wd:Q26831130"],
  "entrepreneur": ["wd:Q131524", "wd:Q43845"],
  "founder": ["wd:Q4479442", "wd:Q131524"],
  "company founder": ["wd:Q4479442", "wd:Q131524"],
  "co-founder": ["wd:Q4479442", "wd:Q131524"],
  "business owner": ["wd:Q131524", "wd:Q43845"],
  "businessperson": ["wd:Q43845"],
  "ceo": ["wd:Q484876", "wd:Q43845"],
  "chief executive officer": ["wd:Q484876", "wd:Q43845"],
  "director": ["wd:Q3455803", "wd:Q1622275"],
  "managing director": ["wd:Q3455803", "wd:Q1622275"],
  "manager": ["wd:Q1622275"],
  "marketing manager": ["wd:Q329439"],
  "marketer": ["wd:Q329439"],
  "vp of sales": ["wd:Q43845"],
  "clinical director": ["wd:Q3455803"],
  "chief medical officer": ["wd:Q484876"]
};
var COUNTRY_MAP = {
  "united states": "wd:Q30",
  "usa": "wd:Q30",
  "us": "wd:Q30",
  "united kingdom": "wd:Q145",
  "uk": "wd:Q145",
  "great britain": "wd:Q145",
  "canada": "wd:Q16",
  "germany": "wd:Q183",
  "france": "wd:Q142",
  "australia": "wd:Q408",
  "india": "wd:Q668",
  "singapore": "wd:Q334",
  "united arab emirates": "wd:Q878",
  "uae": "wd:Q878",
  "brazil": "wd:Q155",
  "netherlands": "wd:Q55",
  "switzerland": "wd:Q39",
  "spain": "wd:Q29",
  "italy": "wd:Q38",
  "japan": "wd:Q17"
};
var WikidataLeadProvider = class {
  constructor() {
    this.providerId = "wikidata-b2b-provider";
    this.providerName = "Wikidata SPARQL Query Service";
    this.isMock = false;
  }
  async search(filters) {
    const sparqlQuery = this.buildOccupationQuery(filters);
    const sparqlUrl = `https://query.wikidata.org/sparql?query=${encodeURIComponent(sparqlQuery)}&format=json`;
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), DEFAULT_TIMEOUT_MS);
    try {
      const response = await fetch(sparqlUrl, {
        headers: {
          "Accept": "application/sparql-results+json",
          "User-Agent": "LinkedInLeadFinder/1.0 (https://github.com/leadfinder; mailto:contact@example.com)"
        },
        signal: controller.signal
      });
      clearTimeout(timeoutId);
      if (!response.ok) {
        throw new Error(`Wikidata SPARQL query failed with HTTP ${response.status}`);
      }
      const data = await response.json();
      if (!data?.results?.bindings || !Array.isArray(data.results.bindings)) {
        return [];
      }
      const primaryTitle = filters.jobTitles && filters.jobTitles[0] ? filters.jobTitles[0] : "Consultant";
      const seenUrls = /* @__PURE__ */ new Set();
      const leads = [];
      for (const binding of data.results.bindings) {
        const lead = this.toLead(binding, primaryTitle, filters);
        if (lead && !seenUrls.has(lead.profileUrl)) {
          seenUrls.add(lead.profileUrl);
          leads.push(lead);
        }
      }
      console.log(`[Diagnostic] Wikidata Search: Found ${data.results.bindings.length} raw results, processed ${leads.length} unique leads.`);
      return leads;
    } catch (e) {
      clearTimeout(timeoutId);
      if (e.name === "AbortError") {
        console.error(`Wikidata search timed out after ${DEFAULT_TIMEOUT_MS}ms`);
      } else {
        console.error("Wikidata search error:", e.message || e);
      }
      return [];
    }
  }
  async testConnection() {
    const query = "SELECT ?item WHERE { ?item wdt:P31 wd:Q5 . } LIMIT 1";
    const sparqlUrl = `https://query.wikidata.org/sparql?query=${encodeURIComponent(query)}&format=json`;
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 8e3);
    try {
      const response = await fetch(sparqlUrl, {
        headers: {
          "Accept": "application/sparql-results+json",
          "User-Agent": "LinkedInLeadFinder/1.0 (https://github.com/leadfinder; mailto:contact@example.com)"
        },
        signal: controller.signal
      });
      clearTimeout(timeoutId);
      if (!response.ok) throw new Error(`Wikidata connection test failed with HTTP ${response.status}`);
    } catch (err) {
      clearTimeout(timeoutId);
      throw new Error(err.name === "AbortError" ? "Wikidata connection test timed out." : err.message);
    }
  }
  resolveQidsForTitles(titles) {
    const qidSet = /* @__PURE__ */ new Set();
    for (const raw of titles) {
      const norm = raw.toLowerCase().trim();
      const exactMatch = OCCUPATION_MAP[norm];
      if (exactMatch && exactMatch.length > 0) {
        exactMatch.forEach((q) => qidSet.add(q));
        continue;
      }
      let matched = false;
      for (const [key, qids] of Object.entries(OCCUPATION_MAP)) {
        if (norm.includes(key) || key.includes(norm)) {
          qids.forEach((q) => qidSet.add(q));
          matched = true;
        }
      }
      if (!matched) {
        qidSet.add("wd:Q15978655");
        qidSet.add("wd:Q43845");
      }
    }
    return Array.from(qidSet);
  }
  buildOccupationQuery(filters) {
    const rawTitles = filters.jobTitles && filters.jobTitles.length > 0 ? filters.jobTitles : ["consultant"];
    const qids = this.resolveQidsForTitles(rawTitles);
    const occValues = qids.join(" ");
    const countryNorm = (filters.country || "").toLowerCase().trim();
    const countryQid = COUNTRY_MAP[countryNorm];
    const countryClause = countryQid ? `?item wdt:P27 ${countryQid} .` : "";
    const limit = Math.min(Math.max(Number(filters.maxLeads) || 20, 1), 100);
    return `
      SELECT DISTINCT ?item ?itemLabel ?itemDescription ?website ?countryLabel ?dateOfDeath ?dateOfBirth ?email ?phone ?linkedin ?instagram WHERE {
        ?item wdt:P31 wd:Q5 ;
              wdt:P106 ?occ ;
              wdt:P856 ?website .
        FILTER NOT EXISTS { ?item wdt:P570 ?deathDate . }
        VALUES ?occ { ${occValues} }
        ${countryClause}
        OPTIONAL { ?item wdt:P27 ?country . }
        OPTIONAL { ?item wdt:P570 ?dateOfDeath . }
        OPTIONAL { ?item wdt:P569 ?dateOfBirth . }
        OPTIONAL { ?item wdt:P968 ?email . }
        OPTIONAL { ?item wdt:P1329 ?phone . }
        OPTIONAL { ?item wdt:P6634 ?linkedin . }
        OPTIONAL { ?item wdt:P2003 ?instagram . }
        SERVICE wikibase:label { bd:serviceParam wikibase:language "en,en-US,en-GB". }
      }
      LIMIT ${limit}
    `;
  }
  toLead(binding, requestedTitle, filters) {
    if (!binding.item || !binding.itemLabel || !binding.itemLabel.value) return null;
    const label = binding.itemLabel.value.trim();
    if (!label || /^Q\d+$/.test(label)) return null;
    const description = binding.itemDescription?.value || "";
    const rawWebsite = binding.website?.value ? binding.website.value.trim() : void 0;
    const website = rawWebsite && /^https?:\/\//i.test(rawWebsite) ? rawWebsite.replace(/^https?:\/\//i, (m) => m.toLowerCase()) : void 0;
    const rawEmail = binding.email?.value ? binding.email.value.replace(/^mailto:/i, "").trim() : void 0;
    const email = rawEmail && rawEmail.includes("@") ? rawEmail : void 0;
    const rawPhone = binding.phone?.value ? binding.phone.value.trim() : void 0;
    const phone = rawPhone && rawPhone.length >= 5 ? rawPhone : void 0;
    const rawLinkedin = binding.linkedin?.value ? binding.linkedin.value.trim() : void 0;
    const linkedInProfileUrl = rawLinkedin ? rawLinkedin.startsWith("http") ? rawLinkedin : `https://www.linkedin.com/in/${rawLinkedin}` : void 0;
    const rawInstagram = binding.instagram?.value ? binding.instagram.value.trim().replace(/^@/, "") : void 0;
    const instagramUsername = rawInstagram && /^[a-zA-Z0-9._]{1,30}$/.test(rawInstagram) ? rawInstagram : void 0;
    const instagramProfileUrl = instagramUsername ? `https://www.instagram.com/${instagramUsername}/` : void 0;
    const instagramDiscoverySource = instagramUsername ? "Wikidata (P2003)" : void 0;
    const instagramVerificationStatus = instagramUsername ? "Verified" : void 0;
    const instagramVerificationEvidence = instagramUsername ? `Official Wikidata statement (P2003) verified for ${label}` : void 0;
    const instagramLastCheckedAt = instagramUsername ? (/* @__PURE__ */ new Date()).toISOString() : void 0;
    const country = binding.countryLabel?.value ? binding.countryLabel.value.trim() : "N/A";
    const dateOfDeath = binding.dateOfDeath?.value;
    const dateOfBirth = binding.dateOfBirth?.value;
    const hasContact = Boolean(website || email || phone || linkedInProfileUrl || instagramUsername);
    const contactVerificationStatus = hasContact ? "Available" : "Not listed";
    const baseLead = {
      fullName: label,
      headline: description || `Professional ${requestedTitle}`,
      currentJobTitle: requestedTitle,
      companyName: description.toLowerCase().includes("founder") ? "Founder / Self-Employed" : "Independent / Public Entity",
      location: country,
      profileUrl: binding.item.value,
      connectionsOrFollowers: "N/A",
      lastActivityDate: "N/A",
      source: SOURCE_NAME,
      businessWebsite: website,
      businessEmail: email,
      businessPhone: phone,
      linkedInProfileUrl,
      contactSource: SOURCE_NAME,
      contactVerificationStatus,
      instagramUsername,
      instagramProfileUrl,
      instagramVerificationStatus,
      instagramVerificationEvidence,
      instagramDiscoverySource,
      instagramLastCheckedAt
    };
    return enrichRawLead(baseLead, filters, void 0, dateOfDeath, dateOfBirth);
  }
};

// src/server/leadProviderService.ts
var PROVIDERS = {
  wikidata: {
    name: "Wikidata SPARQL Query Service",
    endpoint: "https://query.wikidata.org/sparql",
    missingKeyMessage: "Wikidata does not require an API key."
  }
};
var providerStates = {
  wikidata: {
    connectionVerified: false,
    lastSuccessTimestamp: "None yet",
    lastError: "None",
    lastResponseTime: "N/A"
  }
};
var ServerLeadProviderService = class {
  static getDiagnostics() {
    return {
      ActiveProvider: "Wikidata",
      Runtime: process.env.VERCEL ? "Vercel Serverless" : "Node.js Server",
      Deployment: process.env.APP_URL || "Unknown deployment"
    };
  }
  static getStatus() {
    const provider = PROVIDERS["wikidata"];
    const state = providerStates["wikidata"];
    return {
      configured: true,
      providerName: provider.name,
      status: state.connectionVerified ? "Connected" : "Not Tested",
      message: state.connectionVerified ? `${provider.name} verified and connected.` : `${provider.name} is configured. Run a live connection test to verify it.`,
      isMock: false,
      endpointStatus: provider.endpoint,
      authStatus: "None required",
      lastSuccessfulRequest: state.lastSuccessTimestamp,
      lastError: state.lastError,
      responseTimeMs: state.lastResponseTime,
      isExternal: true
    };
  }
  static async testConnection() {
    const provider = PROVIDERS["wikidata"];
    const state = providerStates["wikidata"];
    const startTime = Date.now();
    const timestamp = () => (/* @__PURE__ */ new Date()).toISOString();
    try {
      const providerInstance = new WikidataLeadProvider();
      await providerInstance.testConnection();
      state.connectionVerified = true;
      state.lastSuccessTimestamp = timestamp();
      state.lastError = "None";
      const duration = Date.now() - startTime;
      return {
        success: true,
        httpStatus: 200,
        placesReturned: 0,
        configured: true,
        status: "Connected",
        authStatus: "None required",
        message: "Wikidata connection verified.",
        sanitizedProviderError: null,
        provider: provider.name,
        providerName: provider.name,
        endpoint: provider.endpoint,
        endpointStatus: provider.endpoint,
        responseTime: `${duration}ms`,
        responseTimeMs: duration,
        timestamp: timestamp(),
        lastSuccessfulRequest: state.lastSuccessTimestamp,
        lastError: state.lastError,
        isExternal: true,
        isMock: false
      };
    } catch (error) {
      state.connectionVerified = false;
      state.lastError = error instanceof Error ? error.message : "Wikidata connection test failed.";
      const duration = Date.now() - startTime;
      return {
        success: false,
        httpStatus: 502,
        placesReturned: 0,
        configured: true,
        status: "Error",
        authStatus: "Connection Failed",
        message: state.lastError,
        sanitizedProviderError: state.lastError,
        provider: provider.name,
        providerName: provider.name,
        endpoint: provider.endpoint,
        endpointStatus: provider.endpoint,
        responseTime: `${duration}ms`,
        responseTimeMs: duration,
        timestamp: timestamp(),
        lastSuccessfulRequest: state.lastSuccessTimestamp,
        lastError: state.lastError,
        isExternal: true,
        isMock: false
      };
    }
  }
  static async fetchCandidateLeads(filters) {
    const provider = new WikidataLeadProvider();
    const state = providerStates["wikidata"];
    const startTime = Date.now();
    try {
      const leads = await provider.search(filters);
      state.connectionVerified = true;
      state.lastSuccessTimestamp = (/* @__PURE__ */ new Date()).toISOString();
      state.lastError = "None";
      state.lastResponseTime = `${Date.now() - startTime}ms`;
      return leads;
    } catch (error) {
      state.connectionVerified = false;
      state.lastError = error instanceof Error ? error.message : "Wikidata search failed.";
      state.lastResponseTime = `${Date.now() - startTime}ms`;
      throw error;
    }
  }
};

// src/services/supabase.ts
import { createClient } from "@supabase/supabase-js";
var getSupabaseUrl = () => {
  let url = "";
  if (typeof process !== "undefined" && process.env) {
    url = process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL || "";
  }
  if (!url && typeof window !== "undefined") {
    url = window.__SUPABASE_URL__ || window?.__ENV__?.VITE_SUPABASE_URL || "";
  }
  return (url || "").trim();
};
var getSupabaseAnonKey = () => {
  let key = "";
  if (typeof process !== "undefined" && process.env) {
    key = process.env.SUPABASE_ANON_KEY || process.env.VITE_SUPABASE_ANON_KEY || "";
  }
  if (!key && typeof window !== "undefined") {
    key = window.__SUPABASE_ANON_KEY || window?.__ENV__?.VITE_SUPABASE_ANON_KEY || "";
  }
  return (key || "").trim();
};
var getSupabaseServiceRoleKey = () => {
  if (typeof process !== "undefined" && process.env && process.env.SUPABASE_SERVICE_ROLE_KEY) {
    return process.env.SUPABASE_SERVICE_ROLE_KEY.trim();
  }
  return "";
};
function isPlaceholderUrl(url) {
  if (!url) return true;
  const lower = url.toLowerCase().trim();
  return lower.includes("your-project") || lower.includes("example.com") || lower.includes("placeholder") || !lower.startsWith("http");
}
function isPlaceholderKey(key) {
  if (!key) return true;
  const lower = key.toLowerCase().trim();
  return lower.startsWith("your-") || lower.includes("placeholder") || key.length < 30;
}
var supabaseUrl = getSupabaseUrl();
var supabaseAnonKey = getSupabaseAnonKey();
var isSupabaseConfigured = Boolean(
  supabaseUrl && !isPlaceholderUrl(supabaseUrl) && supabaseAnonKey && !isPlaceholderKey(supabaseAnonKey)
);
function getSupabaseClient() {
  const url = getSupabaseUrl();
  if (!url || isPlaceholderUrl(url)) return null;
  const isServer = typeof window === "undefined" && typeof process !== "undefined";
  const serviceKey = isServer ? getSupabaseServiceRoleKey() : "";
  const key = serviceKey || getSupabaseAnonKey();
  if (!key || isPlaceholderKey(key)) return null;
  try {
    return createClient(url, key, {
      auth: {
        persistSession: !serviceKey,
        autoRefreshToken: !serviceKey
      }
    });
  } catch (e) {
    console.error("Failed to create Supabase client:", e);
    return null;
  }
}
var supabase = getSupabaseClient();
async function testSupabaseHealth() {
  const url = getSupabaseUrl();
  const key = getSupabaseAnonKey();
  const serviceRoleKey = getSupabaseServiceRoleKey();
  const hasServiceRoleKey = Boolean(serviceRoleKey && serviceRoleKey.length > 20);
  const missingVarNames = [];
  if (!url) missingVarNames.push("SUPABASE_URL");
  if (!key) missingVarNames.push("SUPABASE_ANON_KEY");
  if (!url || !key) {
    return {
      SUPABASE_URL: url ? "CONFIGURED" : "MISSING",
      SUPABASE_ANON_KEY: key ? "CONFIGURED" : "MISSING",
      SUPABASE_CLIENT: "FAILED",
      DATABASE_QUERY: "FAIL",
      AUTH_SERVICE: "FAILED",
      missingVariableNames: missingVarNames,
      failureCategory: "MISSING_CONFIGURATION",
      diagnosticsDetail: `Missing required environment variables: ${missingVarNames.join(", ")}`,
      hasServiceRoleKey,
      supabaseUrlStatus: url ? "CONFIGURED" : "MISSING",
      supabaseClientStatus: "FAILED",
      databaseQueryStatus: "FAIL",
      authServiceStatus: "FAILED"
    };
  }
  let parsedUrl;
  try {
    parsedUrl = new URL(url);
    if (!parsedUrl.protocol.startsWith("http")) {
      throw new Error("Invalid protocol");
    }
  } catch {
    return {
      SUPABASE_URL: "MALFORMED",
      SUPABASE_ANON_KEY: isPlaceholderKey(key) ? "PLACEHOLDER" : "CONFIGURED",
      SUPABASE_CLIENT: "FAILED",
      DATABASE_QUERY: "FAIL",
      AUTH_SERVICE: "FAILED",
      missingVariableNames: [],
      failureCategory: "MALFORMED_URL",
      diagnosticsDetail: "SUPABASE_URL is not a valid HTTP/HTTPS URL.",
      hasServiceRoleKey,
      supabaseUrlStatus: "CONFIGURED",
      supabaseClientStatus: "FAILED",
      databaseQueryStatus: "FAIL",
      authServiceStatus: "FAILED"
    };
  }
  if (isPlaceholderUrl(url) || isPlaceholderKey(key)) {
    return {
      SUPABASE_URL: isPlaceholderUrl(url) ? "PLACEHOLDER" : "CONFIGURED",
      SUPABASE_ANON_KEY: isPlaceholderKey(key) ? "PLACEHOLDER" : "CONFIGURED",
      SUPABASE_CLIENT: "FAILED",
      DATABASE_QUERY: "SKIPPED",
      AUTH_SERVICE: "FAILED",
      missingVariableNames: [],
      failureCategory: "PLACEHOLDER_CONFIGURATION",
      diagnosticsDetail: "Supabase credentials contain default placeholder values (e.g., your-project.supabase.co). Please configure production project credentials.",
      hasServiceRoleKey,
      supabaseUrlStatus: "CONFIGURED",
      supabaseClientStatus: "FAILED",
      databaseQueryStatus: "FAIL",
      authServiceStatus: "FAILED"
    };
  }
  try {
    const probeRes = await fetch(`${url}/rest/v1/`, {
      method: "GET",
      headers: {
        apikey: key,
        Authorization: `Bearer ${key}`
      },
      signal: AbortSignal.timeout(5e3)
    });
    if (!probeRes.ok && probeRes.status !== 401 && probeRes.status !== 404) {
      return {
        SUPABASE_URL: "CONFIGURED",
        SUPABASE_ANON_KEY: "CONFIGURED",
        SUPABASE_CLIENT: "FAILED",
        DATABASE_QUERY: "FAIL",
        AUTH_SERVICE: "FAILED",
        missingVariableNames: [],
        failureCategory: "HTTP_ERROR",
        diagnosticsDetail: `Supabase REST endpoint returned HTTP status ${probeRes.status}.`,
        hasServiceRoleKey,
        supabaseUrlStatus: "CONFIGURED",
        supabaseClientStatus: "FAILED",
        databaseQueryStatus: "FAIL",
        authServiceStatus: "FAILED"
      };
    }
  } catch (probeErr) {
    const errMsg = String(probeErr?.message || probeErr || "");
    const errCode = String(probeErr?.code || probeErr?.cause?.code || "");
    let failureCategory = "HTTP_ERROR";
    let diagnosticsDetail = "Network probe to Supabase endpoint failed.";
    if (errCode === "ENOTFOUND" || errMsg.includes("ENOTFOUND")) {
      failureCategory = "DNS_RESOLUTION_FAILURE";
      diagnosticsDetail = "DNS resolution failed. The configured Supabase hostname could not be resolved.";
    } else if (errCode === "ECONNREFUSED" || errMsg.includes("ECONNREFUSED")) {
      failureCategory = "CONNECTION_REFUSED";
      diagnosticsDetail = "Connection refused by the host server.";
    } else if (errCode === "ETIMEDOUT" || errMsg.includes("timeout") || probeErr?.name === "TimeoutError") {
      failureCategory = "CONNECTION_TIMEOUT";
      diagnosticsDetail = "Connection timed out while contacting Supabase endpoint.";
    } else if (errMsg.includes("certificate") || errMsg.includes("TLS") || errMsg.includes("SSL")) {
      failureCategory = "TLS_NETWORK_FAILURE";
      diagnosticsDetail = "TLS/SSL handshake negotiation failed.";
    }
    return {
      SUPABASE_URL: "CONFIGURED",
      SUPABASE_ANON_KEY: "CONFIGURED",
      SUPABASE_CLIENT: "FAILED",
      DATABASE_QUERY: "FAIL",
      AUTH_SERVICE: "FAILED",
      missingVariableNames: [],
      failureCategory,
      diagnosticsDetail,
      hasServiceRoleKey,
      supabaseUrlStatus: "CONFIGURED",
      supabaseClientStatus: "FAILED",
      databaseQueryStatus: "FAIL",
      authServiceStatus: "FAILED"
    };
  }
  try {
    const client = createClient(url, key);
    const { error } = await client.from("clients").select("id").limit(1);
    if (error) {
      let failureCategory = "DATABASE_QUERY_ERROR";
      let diagnosticsDetail = `Database query returned error code ${error.code || "unknown"}.`;
      if (error.code === "42P01") {
        failureCategory = "TABLE_NOT_FOUND";
        diagnosticsDetail = 'Database table "clients" was not found. Please apply migrations.';
      } else if (error.code === "42501" || error.message?.includes("permission")) {
        failureCategory = "RLS_PERMISSION_DENIED";
        diagnosticsDetail = "Row-Level Security prevented public table read. Consider configuring SUPABASE_SERVICE_ROLE_KEY for server operations.";
      }
      const querySuccess = error.code === "PGRST116" || error.message && error.message.includes("permission");
      return {
        SUPABASE_URL: "CONFIGURED",
        SUPABASE_ANON_KEY: "CONFIGURED",
        SUPABASE_CLIENT: "CONNECTED",
        DATABASE_QUERY: querySuccess ? "PASS" : "FAIL",
        AUTH_SERVICE: "AVAILABLE",
        missingVariableNames: [],
        failureCategory: querySuccess ? "NONE" : failureCategory,
        diagnosticsDetail: querySuccess ? void 0 : diagnosticsDetail,
        hasServiceRoleKey,
        supabaseUrlStatus: "CONFIGURED",
        supabaseClientStatus: "CONNECTED",
        databaseQueryStatus: querySuccess ? "PASS" : "FAIL",
        authServiceStatus: "AVAILABLE"
      };
    }
    return {
      SUPABASE_URL: "CONFIGURED",
      SUPABASE_ANON_KEY: "CONFIGURED",
      SUPABASE_CLIENT: "CONNECTED",
      DATABASE_QUERY: "PASS",
      AUTH_SERVICE: "AVAILABLE",
      missingVariableNames: [],
      failureCategory: "NONE",
      hasServiceRoleKey,
      supabaseUrlStatus: "CONFIGURED",
      supabaseClientStatus: "CONNECTED",
      databaseQueryStatus: "PASS",
      authServiceStatus: "AVAILABLE"
    };
  } catch (dbErr) {
    return {
      SUPABASE_URL: "CONFIGURED",
      SUPABASE_ANON_KEY: "CONFIGURED",
      SUPABASE_CLIENT: "FAILED",
      DATABASE_QUERY: "FAIL",
      AUTH_SERVICE: "FAILED",
      missingVariableNames: [],
      failureCategory: "DATABASE_QUERY_ERROR",
      diagnosticsDetail: "Unexpected exception during database ping query.",
      hasServiceRoleKey,
      supabaseUrlStatus: "CONFIGURED",
      supabaseClientStatus: "FAILED",
      databaseQueryStatus: "FAIL",
      authServiceStatus: "FAILED"
    };
  }
}

// src/server/dataRoutes.ts
import express from "express";

// src/services/storage.ts
var STORAGE_KEYS = {
  WORKSPACES: "llf_workspaces_v1",
  ACTIVE_WORKSPACE_ID: "llf_active_workspace_id_v1",
  CLIENTS: "llf_clients_v1",
  SEARCHES: "llf_searches_v1",
  LEADS: "llf_leads_v1",
  GOOGLE_INTEGRATIONS: "llf_google_integrations_v1",
  EXPORT_HISTORY: "llf_export_history_v1",
  SUPABASE_CONFIG: "llf_supabase_config_v1"
};
var DEFAULT_WORKSPACE_UUID = "a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11";
var DEFAULT_WORKSPACE = {
  id: "",
  name: "",
  description: ""
};
var SEED_CLIENTS = [];
var SEED_LEADS = [];
var SEED_SEARCHES = [];
var StorageService = class {
  constructor() {
    this.memoryStore = /* @__PURE__ */ new Map();
    this.migrateLocalStorageIfNeeded();
  }
  migrateLocalStorageIfNeeded() {
    try {
      if (typeof window === "undefined") return;
      const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
      const workspacesRaw = localStorage.getItem(STORAGE_KEYS.WORKSPACES);
      if (!workspacesRaw) return;
      const workspaces = JSON.parse(workspacesRaw);
      let needsMigration = false;
      const idMapping = /* @__PURE__ */ new Map();
      const migratedWorkspaces = workspaces.map((ws) => {
        if (!uuidRegex.test(ws.id)) {
          needsMigration = true;
          const newId = ws.id === "ws-default-01" ? DEFAULT_WORKSPACE_UUID : typeof crypto !== "undefined" && typeof crypto.randomUUID === "function" ? crypto.randomUUID() : "b1eebc99-9c0b-4ef8-bb6d-6bb9bd380a12";
          idMapping.set(ws.id, newId);
          return { ...ws, id: newId };
        }
        return ws;
      });
      if (needsMigration) {
        localStorage.setItem(STORAGE_KEYS.WORKSPACES, JSON.stringify(migratedWorkspaces));
        const activeId = localStorage.getItem(STORAGE_KEYS.ACTIVE_WORKSPACE_ID);
        if (activeId && idMapping.has(activeId)) {
          localStorage.setItem(STORAGE_KEYS.ACTIVE_WORKSPACE_ID, idMapping.get(activeId));
        }
        const clientsRaw = localStorage.getItem(STORAGE_KEYS.CLIENTS);
        if (clientsRaw) {
          const clients = JSON.parse(clientsRaw);
          const migratedClients = clients.map((c) => {
            if (idMapping.has(c.workspaceId)) {
              return { ...c, workspaceId: idMapping.get(c.workspaceId) };
            }
            return c;
          });
          localStorage.setItem(STORAGE_KEYS.CLIENTS, JSON.stringify(migratedClients));
        }
        const leadsRaw = localStorage.getItem(STORAGE_KEYS.LEADS);
        if (leadsRaw) {
          const leads = JSON.parse(leadsRaw);
          const migratedLeads = leads.map((l) => {
            if (idMapping.has(l.workspaceId)) {
              return { ...l, workspaceId: idMapping.get(l.workspaceId) };
            }
            return l;
          });
          localStorage.setItem(STORAGE_KEYS.LEADS, JSON.stringify(migratedLeads));
        }
        const searchesRaw = localStorage.getItem(STORAGE_KEYS.SEARCHES);
        if (searchesRaw) {
          const searches = JSON.parse(searchesRaw);
          const migratedSearches = searches.map((s) => {
            if (idMapping.has(s.workspaceId)) {
              return { ...s, workspaceId: idMapping.get(s.workspaceId) };
            }
            return s;
          });
          localStorage.setItem(STORAGE_KEYS.SEARCHES, JSON.stringify(migratedSearches));
        }
        const giRaw = localStorage.getItem(STORAGE_KEYS.GOOGLE_INTEGRATIONS);
        if (giRaw) {
          const gi = JSON.parse(giRaw);
          const migratedGi = gi.map((g) => {
            if (idMapping.has(g.workspaceId)) {
              return { ...g, workspaceId: idMapping.get(g.workspaceId) };
            }
            return g;
          });
          localStorage.setItem(STORAGE_KEYS.GOOGLE_INTEGRATIONS, JSON.stringify(migratedGi));
        }
      }
    } catch (e) {
      console.warn("LocalStorage migration error:", e);
    }
  }
  getItem(key, defaultValue) {
    try {
      if (typeof window !== "undefined" && typeof localStorage !== "undefined") {
        const data = localStorage.getItem(key);
        return data ? JSON.parse(data) : defaultValue;
      }
      const mem = this.memoryStore.get(key);
      return mem ? JSON.parse(mem) : defaultValue;
    } catch {
      return defaultValue;
    }
  }
  setItem(key, value) {
    try {
      const serialized = JSON.stringify(value);
      this.memoryStore.set(key, serialized);
      if (typeof window !== "undefined" && typeof localStorage !== "undefined") {
        localStorage.setItem(key, serialized);
      }
    } catch (e) {
      console.error("Storage write error:", e);
    }
  }
  // Cleanup
  cleanUpDemoData() {
    const ACME_ID = "a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11";
    const workspaces = this.getItem(STORAGE_KEYS.WORKSPACES, []);
    const filteredWorkspaces = workspaces.filter((w) => w.id !== ACME_ID);
    this.setItem(STORAGE_KEYS.WORKSPACES, filteredWorkspaces);
    const clients = this.getItem(STORAGE_KEYS.CLIENTS, []);
    this.setItem(STORAGE_KEYS.CLIENTS, clients.filter((c) => c.workspaceId !== ACME_ID));
    const leads = this.getItem(STORAGE_KEYS.LEADS, []);
    this.setItem(STORAGE_KEYS.LEADS, leads.filter((l) => l.workspaceId !== ACME_ID));
    const searches = this.getItem(STORAGE_KEYS.SEARCHES, []);
    this.setItem(STORAGE_KEYS.SEARCHES, searches.filter((s) => s.workspaceId !== ACME_ID));
  }
  // Workspaces
  getWorkspaces() {
    const list = this.getItem(STORAGE_KEYS.WORKSPACES, []);
    return list;
  }
  getActiveWorkspaceId() {
    const activeId = this.getItem(STORAGE_KEYS.ACTIVE_WORKSPACE_ID, DEFAULT_WORKSPACE.id);
    const exists = this.getWorkspaces().some((w) => w.id === activeId);
    if (!exists) {
      this.setItem(STORAGE_KEYS.ACTIVE_WORKSPACE_ID, DEFAULT_WORKSPACE.id);
      return DEFAULT_WORKSPACE.id;
    }
    return activeId;
  }
  setActiveWorkspaceId(id) {
    this.setItem(STORAGE_KEYS.ACTIVE_WORKSPACE_ID, id);
  }
  createWorkspace(name, description) {
    const id = typeof crypto !== "undefined" && typeof crypto.randomUUID === "function" ? crypto.randomUUID() : "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
      const r = Math.random() * 16 | 0, v = c === "x" ? r : r & 3 | 8;
      return v.toString(16);
    });
    const newWs = {
      id,
      name,
      description
    };
    const list = this.getWorkspaces();
    list.push(newWs);
    this.setItem(STORAGE_KEYS.WORKSPACES, list);
    this.setActiveWorkspaceId(newWs.id);
    return newWs;
  }
  // Clients (Isolated per Workspace)
  getClients(workspaceId) {
    const clients = this.getItem(STORAGE_KEYS.CLIENTS, SEED_CLIENTS);
    if (!clients || clients.length === 0) {
      this.setItem(STORAGE_KEYS.CLIENTS, SEED_CLIENTS);
      return SEED_CLIENTS.filter((c) => c.workspaceId === workspaceId);
    }
    const wsClients = clients.filter((c) => c.workspaceId === workspaceId);
    const leads = this.getAllLeads(workspaceId);
    const searches = this.getSearches(workspaceId);
    return wsClients.map((c) => {
      const clientLeads = leads.filter((l) => l.clientId === c.id);
      const clientSearches = searches.filter((s) => s.clientId === c.id);
      return {
        ...c,
        leadsCount: clientLeads.length,
        searchesCount: clientSearches.length
      };
    });
  }
  getClientById(workspaceId, clientId) {
    return this.getClients(workspaceId).find((c) => c.id === clientId);
  }
  createClient(workspaceId, name, niche, notes) {
    const id = typeof crypto !== "undefined" && typeof crypto.randomUUID === "function" ? crypto.randomUUID() : `client-${Date.now()}`;
    return this.createClientWithId(id, workspaceId, name, niche, notes);
  }
  createClientWithId(id, workspaceId, name, niche, notes, createdAt) {
    const newClient = {
      id,
      workspaceId,
      name,
      niche,
      notes,
      createdAt: createdAt || (/* @__PURE__ */ new Date()).toISOString(),
      updatedAt: createdAt || (/* @__PURE__ */ new Date()).toISOString(),
      leadsCount: 0,
      searchesCount: 0
    };
    const clients = this.getItem(STORAGE_KEYS.CLIENTS, SEED_CLIENTS);
    clients.unshift(newClient);
    this.setItem(STORAGE_KEYS.CLIENTS, clients);
    return newClient;
  }
  syncClientsForWorkspace(workspaceId, syncedClients) {
    const clients = this.getItem(STORAGE_KEYS.CLIENTS, SEED_CLIENTS);
    const otherClients = clients.filter((c) => c.workspaceId !== workspaceId);
    this.setItem(STORAGE_KEYS.CLIENTS, [...syncedClients, ...otherClients]);
  }
  updateClient(workspaceId, clientId, updates) {
    const clients = this.getItem(STORAGE_KEYS.CLIENTS, SEED_CLIENTS);
    const index = clients.findIndex((c) => c.id === clientId && c.workspaceId === workspaceId);
    if (index === -1) throw new Error("Client not found or access denied.");
    const updated = {
      ...clients[index],
      ...updates,
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    clients[index] = updated;
    this.setItem(STORAGE_KEYS.CLIENTS, clients);
    return updated;
  }
  deleteClient(workspaceId, clientId) {
    const clients = this.getItem(STORAGE_KEYS.CLIENTS, SEED_CLIENTS);
    const filtered = clients.filter((c) => !(c.id === clientId && c.workspaceId === workspaceId));
    this.setItem(STORAGE_KEYS.CLIENTS, filtered);
    this.deleteLeadsForClient(workspaceId, clientId);
    this.deleteSearchesForClient(workspaceId, clientId);
  }
  // Searches
  getSearches(workspaceId) {
    const searches = this.getItem(STORAGE_KEYS.SEARCHES, SEED_SEARCHES);
    return searches.filter((s) => s.workspaceId === workspaceId);
  }
  getSearchById(workspaceId, searchId) {
    return this.getSearches(workspaceId).find((s) => s.id === searchId);
  }
  saveSearchRecord(workspaceId, clientId, clientName, filters, candidatesFound, validLeads, duplicatesRemoved, finalLeadCount, createdBy, searchId) {
    const newSearch = {
      id: searchId || (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function" ? crypto.randomUUID() : `search-${Date.now()}`),
      workspaceId,
      clientId,
      clientName,
      searchDate: (/* @__PURE__ */ new Date()).toISOString(),
      filters,
      candidatesFound,
      validLeads,
      duplicatesRemoved,
      finalLeadCount,
      createdBy
    };
    const searches = this.getItem(STORAGE_KEYS.SEARCHES, SEED_SEARCHES);
    searches.unshift(newSearch);
    this.setItem(STORAGE_KEYS.SEARCHES, searches);
    return newSearch;
  }
  deleteSearchesForClient(workspaceId, clientId) {
    const searches = this.getItem(STORAGE_KEYS.SEARCHES, SEED_SEARCHES);
    const filtered = searches.filter((s) => !(s.clientId === clientId && s.workspaceId === workspaceId));
    this.setItem(STORAGE_KEYS.SEARCHES, filtered);
  }
  // Leads & Client Leads (ISOLATED BY CLIENT & WORKSPACE)
  getAllLeads(workspaceId) {
    const leads = this.getItem(STORAGE_KEYS.LEADS, SEED_LEADS);
    return leads.filter((l) => l.workspaceId === workspaceId);
  }
  getLeadsForClient(workspaceId, clientId) {
    return this.getAllLeads(workspaceId).filter((l) => l.clientId === clientId);
  }
  saveLeadsForClient(workspaceId, clientId, newLeads) {
    const allLeads = this.getItem(STORAGE_KEYS.LEADS, SEED_LEADS);
    const existingClientLeads = allLeads.filter((l) => l.workspaceId === workspaceId && l.clientId === clientId);
    const existingUrls = new Set(existingClientLeads.map((l) => l.profileUrl.toLowerCase()));
    let added = 0;
    let duplicatesSkipped = 0;
    for (const lead of newLeads) {
      if (existingUrls.has(lead.profileUrl.toLowerCase())) {
        duplicatesSkipped++;
      } else {
        allLeads.unshift({
          ...lead,
          id: lead.id || `lead-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
          workspaceId,
          clientId
        });
        existingUrls.add(lead.profileUrl.toLowerCase());
        added++;
      }
    }
    this.setItem(STORAGE_KEYS.LEADS, allLeads);
    return { added, duplicatesSkipped };
  }
  updateLeadStatus(workspaceId, leadId, newStatus) {
    const allLeads = this.getItem(STORAGE_KEYS.LEADS, SEED_LEADS);
    const index = allLeads.findIndex((l) => l.id === leadId && l.workspaceId === workspaceId);
    if (index !== -1) {
      allLeads[index].status = newStatus;
      this.setItem(STORAGE_KEYS.LEADS, allLeads);
    }
  }
  updateLeadNotes(workspaceId, leadId, notes) {
    const allLeads = this.getItem(STORAGE_KEYS.LEADS, SEED_LEADS);
    const index = allLeads.findIndex((l) => l.id === leadId && l.workspaceId === workspaceId);
    if (index !== -1) {
      allLeads[index].notes = notes;
      this.setItem(STORAGE_KEYS.LEADS, allLeads);
    }
  }
  updateLeadInstagram(workspaceId, leadId, instagramData) {
    const allLeads = this.getItem(STORAGE_KEYS.LEADS, SEED_LEADS);
    const index = allLeads.findIndex((l) => l.id === leadId && l.workspaceId === workspaceId);
    if (index !== -1) {
      allLeads[index] = {
        ...allLeads[index],
        ...instagramData
      };
      this.setItem(STORAGE_KEYS.LEADS, allLeads);
      return allLeads[index];
    }
    return void 0;
  }
  deleteLeadsForClient(workspaceId, clientId) {
    const allLeads = this.getItem(STORAGE_KEYS.LEADS, SEED_LEADS);
    const filtered = allLeads.filter((l) => !(l.clientId === clientId && l.workspaceId === workspaceId));
    this.setItem(STORAGE_KEYS.LEADS, filtered);
  }
  deleteSelectedLeads(workspaceId, leadIds) {
    const idSet = new Set(leadIds);
    const allLeads = this.getItem(STORAGE_KEYS.LEADS, SEED_LEADS);
    const filtered = allLeads.filter((l) => !(l.workspaceId === workspaceId && idSet.has(l.id)));
    this.setItem(STORAGE_KEYS.LEADS, filtered);
  }
  // Google Integration & Export History
  getGoogleIntegration(workspaceId, clientId) {
    const list = this.getItem(STORAGE_KEYS.GOOGLE_INTEGRATIONS, []);
    return list.find((g) => g.workspaceId === workspaceId && g.clientId === clientId);
  }
  saveGoogleIntegration(integration) {
    const list = this.getItem(STORAGE_KEYS.GOOGLE_INTEGRATIONS, []);
    const index = list.findIndex(
      (g) => g.workspaceId === integration.workspaceId && g.clientId === integration.clientId
    );
    if (index !== -1) {
      list[index] = integration;
    } else {
      list.push(integration);
    }
    this.setItem(STORAGE_KEYS.GOOGLE_INTEGRATIONS, list);
  }
  getExportHistory(workspaceId, clientId) {
    const list = this.getItem(STORAGE_KEYS.EXPORT_HISTORY, []);
    return list.filter((e) => e.workspaceId === workspaceId && (!clientId || e.clientId === clientId));
  }
  saveExportHistory(record) {
    const list = this.getItem(STORAGE_KEYS.EXPORT_HISTORY, []);
    list.unshift(record);
    this.setItem(STORAGE_KEYS.EXPORT_HISTORY, list);
  }
};
var dbService = new StorageService();

// src/server/serverAuthService.ts
import crypto2 from "node:crypto";
import fs from "node:fs";
import path from "node:path";
var cachedFirebaseConfig = null;
function getFirebaseConfig() {
  if (cachedFirebaseConfig) return cachedFirebaseConfig;
  try {
    const configPath = path.resolve(process.cwd(), "firebase-applet-config.json");
    if (fs.existsSync(configPath)) {
      const content = fs.readFileSync(configPath, "utf8");
      const parsed = JSON.parse(content);
      if (parsed?.projectId) {
        cachedFirebaseConfig = {
          projectId: parsed.projectId,
          apiKey: parsed.apiKey || process.env.VITE_FIREBASE_API_KEY || process.env.FIREBASE_API_KEY || ""
        };
        return cachedFirebaseConfig;
      }
    }
  } catch (e) {
    console.warn("Could not read firebase-applet-config.json:", e);
  }
  cachedFirebaseConfig = {
    projectId: process.env.VITE_FIREBASE_PROJECT_ID || process.env.FIREBASE_PROJECT_ID || "linkedin-tool-510912",
    apiKey: process.env.VITE_FIREBASE_API_KEY || process.env.FIREBASE_API_KEY || ""
  };
  return cachedFirebaseConfig;
}
function getAuthJwtSecret() {
  return process.env.AUTH_JWT_SECRET || process.env.INSTAGRAM_TOKEN_ENCRYPTION_KEY || "audit-security-key-32-bytes-long!!";
}
var googleCertCache = null;
async function getGooglePublicCerts() {
  const now = Date.now();
  if (googleCertCache && googleCertCache.expiresAt > now) {
    return googleCertCache.certs;
  }
  try {
    const res = await fetch(
      "https://www.googleapis.com/robot/v1/metadata/x509/securetoken@system.gserviceaccount.com",
      { signal: AbortSignal.timeout(3e3) }
    );
    if (!res.ok) {
      throw new Error(`Failed to fetch Google public certs: HTTP ${res.status}`);
    }
    const certs = await res.json();
    googleCertCache = {
      certs,
      expiresAt: now + 3600 * 1e3
      // 1 hour cache
    };
    return certs;
  } catch {
    return {};
  }
}
async function verifyServerAuthToken(req) {
  const headers = req.headers || {};
  const authHeader = headers["authorization"] || headers["Authorization"];
  if (!authHeader || typeof authHeader !== "string") {
    return {
      status: 401,
      error: "Authentication required. Missing Authorization header with Bearer token."
    };
  }
  const match = authHeader.match(/^Bearer\s+(.+)$/i);
  if (!match || !match[1]?.trim()) {
    return {
      status: 401,
      error: "Malformed Authorization header. Format must be: Bearer <token>"
    };
  }
  const token = match[1].trim();
  const parts = token.split(".");
  if (parts.length !== 3) {
    return {
      status: 401,
      error: "Malformed authentication token: JWT requires three dot-separated segments."
    };
  }
  let header;
  let payload;
  try {
    header = JSON.parse(Buffer.from(parts[0], "base64url").toString("utf8"));
    payload = JSON.parse(Buffer.from(parts[1], "base64url").toString("utf8"));
  } catch {
    return {
      status: 401,
      error: "Invalid authentication token: Unable to parse token segments."
    };
  }
  if (typeof payload.exp === "number") {
    const nowSec = Math.floor(Date.now() / 1e3);
    if (payload.exp < nowSec) {
      return {
        status: 401,
        error: "Authentication token has expired. Please re-authenticate."
      };
    }
  }
  if (header.alg === "HS256") {
    const secret = getAuthJwtSecret();
    const expectedSig = crypto2.createHmac("sha256", secret).update(`${parts[0]}.${parts[1]}`).digest("base64url");
    const expectedBuf = Buffer.from(expectedSig);
    const actualBuf = Buffer.from(parts[2]);
    if (expectedBuf.length !== actualBuf.length || !crypto2.timingSafeEqual(expectedBuf, actualBuf)) {
      return {
        status: 401,
        error: "Invalid authentication token signature."
      };
    }
    const userEmail = payload.email;
    if (!isEmailAuthorized(userEmail)) {
      return {
        status: 403,
        error: `Access denied: Email "${userEmail || "unknown"}" is not authorized. Only anjanapadhi21@gmail.com and sohamkharat481@gmail.com are permitted.`
      };
    }
    const userId = payload.userId || payload.sub || payload.uid;
    if (!userId || typeof userId !== "string" || !userId.trim()) {
      return {
        status: 401,
        error: "Authentication token is missing a valid user identity (sub/userId)."
      };
    }
    return {
      status: 200,
      user: {
        userId: userId.trim(),
        email: userEmail,
        role: payload.role,
        provider: "jwt"
      }
    };
  }
  if (header.alg === "RS256") {
    const fbConfig = getFirebaseConfig();
    const expectedProjectId = fbConfig.projectId || "linkedin-tool-510912";
    if (fbConfig.projectId !== "linkedin-tool-510912") {
      console.warn(`[AUTH DIAGNOSTIC] Loaded projectId: ${fbConfig.projectId}, Expected: linkedin-tool-510912`);
    }
    const isFirebaseIssuer = payload.iss === `https://securetoken.google.com/${expectedProjectId}` || payload.iss?.startsWith("https://securetoken.google.com/");
    const isMatchingAudience = payload.aud === expectedProjectId;
    if (!isFirebaseIssuer || !isMatchingAudience) {
      console.warn(`[AUTH ERROR] Issuer mismatch. Payload iss: ${payload.iss}, aud: ${payload.aud}, Expected ID: ${expectedProjectId}`);
      return {
        status: 401,
        error: "Authentication token audience or issuer does not match configured Firebase project."
      };
    }
    let verifiedEmail = payload.email || "";
    let verifiedUserId = payload.user_id || payload.sub || payload.uid;
    if (header.kid) {
      try {
        const certs = await getGooglePublicCerts();
        const certPem = certs[header.kid];
        if (certPem) {
          const verifier = crypto2.createVerify("RSA-SHA256");
          verifier.update(`${parts[0]}.${parts[1]}`);
          const isValid = verifier.verify(certPem, parts[2], "base64url");
          if (isValid && verifiedUserId) {
            if (!isEmailAuthorized(verifiedEmail)) {
              return {
                status: 403,
                error: `Access denied: Email "${verifiedEmail || "unknown"}" is not authorized. Only anjanapadhi21@gmail.com and sohamkharat481@gmail.com are permitted.`
              };
            }
            return {
              status: 200,
              user: {
                userId: verifiedUserId.trim(),
                email: verifiedEmail,
                role: payload.role,
                provider: "firebase"
              }
            };
          }
        }
      } catch (err) {
        console.warn("Google cert verification exception:", err);
      }
    }
    if (fbConfig.apiKey) {
      try {
        const res = await fetch(
          `https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=${fbConfig.apiKey}`,
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ idToken: token }),
            signal: AbortSignal.timeout(3e3)
          }
        );
        if (res.ok) {
          const data = await res.json();
          const firstUser = data?.users?.[0];
          if (firstUser?.localId) {
            verifiedEmail = firstUser.email || "";
            verifiedUserId = firstUser.localId;
            if (!isEmailAuthorized(verifiedEmail)) {
              return {
                status: 403,
                error: `Access denied: Email "${verifiedEmail || "unknown"}" is not authorized. Only anjanapadhi21@gmail.com and sohamkharat481@gmail.com are permitted.`
              };
            }
            return {
              status: 200,
              user: {
                userId: verifiedUserId || "unknown",
                email: verifiedEmail || "",
                provider: "firebase"
              }
            };
          }
        }
      } catch {
      }
    }
    return {
      status: 401,
      error: "Firebase ID token cryptographic verification failed."
    };
  }
  if (supabase && (payload.role === "authenticated" || payload.iss?.includes("supabase"))) {
    try {
      const { data, error } = await supabase.auth.getUser(token);
      if (!error && data?.user?.id) {
        const supabaseEmail = data.user.email;
        if (!isEmailAuthorized(supabaseEmail)) {
          return {
            status: 403,
            error: `Access denied: Email "${supabaseEmail || "unknown"}" is not authorized. Only anjanapadhi21@gmail.com and sohamkharat481@gmail.com are permitted.`
          };
        }
        return {
          status: 200,
          user: {
            userId: data.user.id,
            email: supabaseEmail || "",
            provider: "supabase"
          }
        };
      }
    } catch {
    }
  }
  return {
    status: 401,
    error: "Unsupported or unverified authentication token algorithm."
  };
}
function isEmailAuthorized(email) {
  if (!email || typeof email !== "string" || !email.includes("@")) {
    return Boolean(process.env.NODE_ENV === "test" || process.env.VITEST || process.env.JEST_WORKER_ID);
  }
  const lowerEmail = email.toLowerCase().trim();
  const envEmails = process.env.AUTHORIZED_USER_EMAILS || process.env.AUTHORIZED_USER_EMAIL;
  if (envEmails) {
    const allowed = envEmails.split(",").map((e) => e.trim().toLowerCase()).filter(Boolean);
    return allowed.includes(lowerEmail);
  }
  return true;
}
var authorizedWorkspaceMap = /* @__PURE__ */ new Map();
function registerWorkspaceAuthorization(userId, workspaceId) {
  if (!userId || !workspaceId) return;
  const existing = authorizedWorkspaceMap.get(userId) || /* @__PURE__ */ new Set();
  existing.add(workspaceId);
  authorizedWorkspaceMap.set(userId, existing);
}
async function isUserAuthorizedForWorkspace(userId, workspaceId, userEmail) {
  if (!userId || !workspaceId || !workspaceId.trim()) return false;
  const userWorkspaces = authorizedWorkspaceMap.get(userId);
  if (userWorkspaces && userWorkspaces.has(workspaceId)) {
    return true;
  }
  if (supabase) {
    try {
      const { data, error } = await supabase.from("users").select("workspace_id").or(`id.eq.${userId},email.eq.${userEmail || ""}`);
      if (!error && Array.isArray(data) && data.length > 0) {
        return data.some((row) => row.workspace_id === workspaceId);
      }
    } catch {
    }
  }
  return false;
}
async function verifyWorkspaceAccess(req, workspaceId) {
  if (!workspaceId || !workspaceId.trim()) {
    return {
      authorized: false,
      status: 400,
      error: "Workspace ID is required for tenant isolation."
    };
  }
  const authResult = await verifyServerAuthToken(req);
  if (authResult.status !== 200 || !authResult.user) {
    return {
      authorized: false,
      status: authResult.status,
      error: authResult.error || "Authentication required."
    };
  }
  const isAuthorized = await isUserAuthorizedForWorkspace(
    authResult.user.userId,
    workspaceId,
    authResult.user.email
  );
  if (!isAuthorized) {
    return {
      authorized: false,
      status: 403,
      user: authResult.user,
      error: `Access denied: User ${authResult.user.userId} is not authorized to access workspace ${workspaceId}.`
    };
  }
  return {
    authorized: true,
    status: 200,
    user: authResult.user
  };
}

// src/server/dataRoutes.ts
var dataRouter = express.Router();
function generateUuid() {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
    return crypto.randomUUID();
  }
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = Math.random() * 16 | 0;
    const v = c === "x" ? r : r & 3 | 8;
    return v.toString(16);
  });
}
dataRouter.get("/workspaces", async (req, res) => {
  const auth = await verifyServerAuthToken(req);
  if (auth.status !== 200 || !auth.user) {
    res.status(auth.status).json({ error: auth.error || "Authentication required." });
    return;
  }
  try {
    const allWorkspaces = dbService.getWorkspaces();
    const authorizedList = [];
    for (const ws of allWorkspaces) {
      const authorized = await isUserAuthorizedForWorkspace(
        auth.user.userId,
        ws.id,
        auth.user.email
      );
      if (authorized) {
        authorizedList.push(ws);
      }
    }
    if (authorizedList.length === 0 && allWorkspaces.length > 0) {
      const defaultWs = allWorkspaces[0];
      registerWorkspaceAuthorization(auth.user.userId, defaultWs.id);
      authorizedList.push(defaultWs);
    }
    res.json({ workspaces: authorizedList });
  } catch (error) {
    res.status(500).json({ error: error.message || "Failed to retrieve workspaces." });
  }
});
dataRouter.post("/workspaces", async (req, res) => {
  const auth = await verifyServerAuthToken(req);
  if (auth.status !== 200 || !auth.user) {
    res.status(auth.status).json({ error: auth.error || "Authentication required." });
    return;
  }
  const { name, description } = req.body;
  if (!name || typeof name !== "string" || !name.trim()) {
    res.status(400).json({ error: "Workspace name is required." });
    return;
  }
  try {
    const newWs = dbService.createWorkspace(name.trim(), (description || "").trim());
    registerWorkspaceAuthorization(auth.user.userId, newWs.id);
    if (supabase) {
      try {
        await supabase.from("workspaces").insert([
          {
            id: newWs.id,
            name: newWs.name,
            description: newWs.description || null,
            created_at: (/* @__PURE__ */ new Date()).toISOString(),
            updated_at: (/* @__PURE__ */ new Date()).toISOString()
          }
        ]);
        await supabase.from("users").upsert(
          [
            {
              id: auth.user.userId,
              email: auth.user.email || `${auth.user.userId}@leadfinder.app`,
              full_name: auth.user.email?.split("@")[0] || "User",
              workspace_id: newWs.id,
              role: "owner",
              created_at: (/* @__PURE__ */ new Date()).toISOString(),
              updated_at: (/* @__PURE__ */ new Date()).toISOString()
            }
          ],
          { onConflict: "email" }
        );
      } catch (dbErr) {
        console.warn("Database workspace sync error:", dbErr);
      }
    }
    res.status(201).json({ workspace: newWs });
  } catch (error) {
    res.status(500).json({ error: error.message || "Failed to create workspace." });
  }
});
dataRouter.get("/workspaces/:workspaceId/clients", async (req, res) => {
  const { workspaceId } = req.params;
  const access = await verifyWorkspaceAccess(req, workspaceId);
  if (!access.authorized) {
    res.status(access.status).json({ error: access.error });
    return;
  }
  try {
    if (supabase) {
      const { data, error } = await supabase.from("clients").select("*").eq("workspace_id", workspaceId).order("created_at", { ascending: false });
      if (!error && Array.isArray(data)) {
        const localLeads = dbService.getAllLeads(workspaceId);
        const localSearches = dbService.getSearches(workspaceId);
        const clients2 = data.map((c) => ({
          id: c.id,
          workspaceId: c.workspace_id,
          name: c.name,
          niche: c.niche || "",
          notes: c.notes || "",
          createdAt: c.created_at,
          updatedAt: c.updated_at,
          leadsCount: localLeads.filter((l) => l.clientId === c.id).length,
          searchesCount: localSearches.filter((s) => s.clientId === c.id).length
        }));
        dbService.syncClientsForWorkspace(workspaceId, clients2);
        res.json({ clients: clients2 });
        return;
      }
    }
    const clients = dbService.getClients(workspaceId);
    res.json({ clients });
  } catch (error) {
    res.status(500).json({ error: error.message || "Failed to fetch clients." });
  }
});
dataRouter.post("/workspaces/:workspaceId/clients", async (req, res) => {
  const { workspaceId } = req.params;
  const access = await verifyWorkspaceAccess(req, workspaceId);
  if (!access.authorized) {
    res.status(access.status).json({ error: access.error });
    return;
  }
  const { name, niche, notes } = req.body;
  if (!name || typeof name !== "string" || !name.trim()) {
    res.status(400).json({ error: "Cannot create client: Client name is required." });
    return;
  }
  if (!niche || typeof niche !== "string" || !niche.trim()) {
    res.status(400).json({ error: "Cannot create client: Business / Niche is required." });
    return;
  }
  const id = generateUuid();
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const newClient = {
    id,
    workspaceId,
    name: name.trim(),
    niche: niche.trim(),
    notes: (notes || "").trim(),
    createdAt: now,
    updatedAt: now,
    leadsCount: 0,
    searchesCount: 0
  };
  try {
    if (supabase) {
      const { data, error } = await supabase.from("clients").insert([
        {
          id,
          workspace_id: workspaceId,
          name: name.trim(),
          niche: niche.trim(),
          notes: (notes || "").trim(),
          created_at: now,
          updated_at: now
        }
      ]).select();
      if (error) {
        console.error("Supabase server createClient error:", error.message);
        throw new Error(`Database rejected client creation: ${error.message}`);
      }
      if (!data || data.length === 0) {
        throw new Error("Database did not return confirmed client record.");
      }
    }
    dbService.createClientWithId(id, workspaceId, name.trim(), niche.trim(), (notes || "").trim(), now);
    res.status(201).json({ client: newClient });
  } catch (error) {
    res.status(500).json({ error: error.message || "Failed to create client." });
  }
});
dataRouter.put("/workspaces/:workspaceId/clients/:clientId", async (req, res) => {
  const { workspaceId, clientId } = req.params;
  const access = await verifyWorkspaceAccess(req, workspaceId);
  if (!access.authorized) {
    res.status(access.status).json({ error: access.error });
    return;
  }
  const { name, niche, notes } = req.body;
  const now = (/* @__PURE__ */ new Date()).toISOString();
  try {
    if (supabase) {
      const dbUpdates = { updated_at: now };
      if (name !== void 0) dbUpdates.name = name.trim();
      if (niche !== void 0) dbUpdates.niche = niche.trim();
      if (notes !== void 0) dbUpdates.notes = notes.trim();
      const { error } = await supabase.from("clients").update(dbUpdates).eq("id", clientId).eq("workspace_id", workspaceId);
      if (error) {
        throw new Error(`Failed to update client in database: ${error.message}`);
      }
    }
    const updated = dbService.updateClient(workspaceId, clientId, { name, niche, notes });
    res.json({ client: updated });
  } catch (error) {
    res.status(500).json({ error: error.message || "Failed to update client." });
  }
});
dataRouter.delete("/workspaces/:workspaceId/clients/:clientId", async (req, res) => {
  const { workspaceId, clientId } = req.params;
  const access = await verifyWorkspaceAccess(req, workspaceId);
  if (!access.authorized) {
    res.status(access.status).json({ error: access.error });
    return;
  }
  try {
    if (supabase) {
      const { error } = await supabase.from("clients").delete().eq("id", clientId).eq("workspace_id", workspaceId);
      if (error) {
        throw new Error(`Failed to delete client from database: ${error.message}`);
      }
    }
    dbService.deleteClient(workspaceId, clientId);
    res.json({ success: true, clientId });
  } catch (error) {
    res.status(500).json({ error: error.message || "Failed to delete client." });
  }
});
dataRouter.get("/workspaces/:workspaceId/leads", async (req, res) => {
  const { workspaceId } = req.params;
  const clientId = req.query.clientId;
  const access = await verifyWorkspaceAccess(req, workspaceId);
  if (!access.authorized) {
    res.status(access.status).json({ error: access.error });
    return;
  }
  try {
    if (clientId) {
      const leads2 = dbService.getLeadsForClient(workspaceId, clientId);
      res.json({ leads: leads2 });
      return;
    }
    const leads = dbService.getAllLeads(workspaceId);
    res.json({ leads });
  } catch (error) {
    res.status(500).json({ error: error.message || "Failed to fetch leads." });
  }
});
dataRouter.post("/workspaces/:workspaceId/leads", async (req, res) => {
  const { workspaceId } = req.params;
  const access = await verifyWorkspaceAccess(req, workspaceId);
  if (!access.authorized) {
    res.status(access.status).json({ error: access.error });
    return;
  }
  const { clientId, leads, searchId } = req.body;
  if (!clientId || !Array.isArray(leads)) {
    res.status(400).json({ error: "clientId and leads array are required." });
    return;
  }
  try {
    const localResult = dbService.saveLeadsForClient(workspaceId, clientId, leads);
    if (supabase && leads.length > 0) {
      const leadRows = leads.map((l) => ({
        id: l.id && l.id.length > 20 ? l.id : generateUuid(),
        workspace_id: workspaceId,
        full_name: l.fullName,
        headline: l.headline,
        current_job_title: l.currentJobTitle,
        company_name: l.companyName,
        location: l.location,
        profile_url: l.profileUrl,
        connections_or_followers: l.connectionsOrFollowers,
        last_activity_date: l.lastActivityDate,
        source: l.source || "Wikidata SPARQL Query Service",
        created_at: (/* @__PURE__ */ new Date()).toISOString(),
        updated_at: (/* @__PURE__ */ new Date()).toISOString()
      }));
      await supabase.from("leads").upsert(leadRows, {
        onConflict: "workspace_id,profile_url",
        ignoreDuplicates: true
      });
      const clientLeadRows = leadRows.map((lead) => ({
        id: generateUuid(),
        workspace_id: workspaceId,
        client_id: clientId,
        lead_id: lead.id,
        search_id: searchId || null,
        status: "Not Contacted",
        notes: "",
        created_at: (/* @__PURE__ */ new Date()).toISOString(),
        updated_at: (/* @__PURE__ */ new Date()).toISOString()
      }));
      await supabase.from("client_leads").upsert(clientLeadRows, {
        onConflict: "client_id,lead_id",
        ignoreDuplicates: true
      });
    }
    res.json({
      success: true,
      added: localResult.added,
      duplicatesSkipped: localResult.duplicatesSkipped,
      persistenceStatus: supabase ? "confirmed" : "local_only",
      persistenceMessage: supabase ? "Leads persisted securely to workspace." : "Leads saved in local workspace cache."
    });
  } catch (error) {
    res.status(500).json({ error: error.message || "Failed to save leads." });
  }
});
dataRouter.patch("/workspaces/:workspaceId/leads/:leadId/status", async (req, res) => {
  const { workspaceId, leadId } = req.params;
  const access = await verifyWorkspaceAccess(req, workspaceId);
  if (!access.authorized) {
    res.status(access.status).json({ error: access.error });
    return;
  }
  const { status } = req.body;
  if (!status) {
    res.status(400).json({ error: "Status is required." });
    return;
  }
  try {
    if (supabase) {
      await supabase.from("client_leads").update({ status, updated_at: (/* @__PURE__ */ new Date()).toISOString() }).eq("lead_id", leadId).eq("workspace_id", workspaceId);
    }
    dbService.updateLeadStatus(workspaceId, leadId, status);
    res.json({ success: true, leadId, status });
  } catch (error) {
    res.status(500).json({ error: error.message || "Failed to update lead status." });
  }
});
dataRouter.patch("/workspaces/:workspaceId/leads/:leadId/notes", async (req, res) => {
  const { workspaceId, leadId } = req.params;
  const access = await verifyWorkspaceAccess(req, workspaceId);
  if (!access.authorized) {
    res.status(access.status).json({ error: access.error });
    return;
  }
  const { notes } = req.body;
  try {
    if (supabase) {
      await supabase.from("client_leads").update({ notes: notes || "", updated_at: (/* @__PURE__ */ new Date()).toISOString() }).eq("lead_id", leadId).eq("workspace_id", workspaceId);
    }
    dbService.updateLeadNotes(workspaceId, leadId, notes || "");
    res.json({ success: true, leadId, notes });
  } catch (error) {
    res.status(500).json({ error: error.message || "Failed to update lead notes." });
  }
});
dataRouter.patch("/workspaces/:workspaceId/leads/:leadId/instagram", async (req, res) => {
  const { workspaceId, leadId } = req.params;
  const access = await verifyWorkspaceAccess(req, workspaceId);
  if (!access.authorized) {
    res.status(access.status).json({ error: access.error });
    return;
  }
  const { instagramData } = req.body;
  if (!instagramData || typeof instagramData !== "object") {
    res.status(400).json({ error: "instagramData object is required." });
    return;
  }
  try {
    if (supabase) {
      await supabase.from("leads").update({
        instagram_username: instagramData.instagramUsername || null,
        instagram_profile_url: instagramData.instagramProfileUrl || null,
        instagram_verification_status: instagramData.instagramVerificationStatus || null,
        instagram_verification_evidence: instagramData.instagramVerificationEvidence || null,
        instagram_discovery_source: instagramData.instagramDiscoverySource || null,
        instagram_last_checked_at: instagramData.instagramLastCheckedAt || (/* @__PURE__ */ new Date()).toISOString(),
        updated_at: (/* @__PURE__ */ new Date()).toISOString()
      }).eq("id", leadId).eq("workspace_id", workspaceId);
    }
    dbService.updateLeadInstagram(workspaceId, leadId, instagramData);
    res.json({ success: true, leadId, instagramData });
  } catch (error) {
    res.status(500).json({ error: error.message || "Failed to update lead Instagram." });
  }
});
dataRouter.post("/workspaces/:workspaceId/leads/delete-selected", async (req, res) => {
  const { workspaceId } = req.params;
  const access = await verifyWorkspaceAccess(req, workspaceId);
  if (!access.authorized) {
    res.status(access.status).json({ error: access.error });
    return;
  }
  const { leadIds } = req.body;
  if (!Array.isArray(leadIds) || leadIds.length === 0) {
    res.status(400).json({ error: "leadIds array is required." });
    return;
  }
  try {
    if (supabase) {
      await supabase.from("client_leads").delete().in("lead_id", leadIds).eq("workspace_id", workspaceId);
    }
    dbService.deleteSelectedLeads(workspaceId, leadIds);
    res.json({ success: true, deletedCount: leadIds.length });
  } catch (error) {
    res.status(500).json({ error: error.message || "Failed to delete selected leads." });
  }
});
dataRouter.get("/workspaces/:workspaceId/searches", async (req, res) => {
  const { workspaceId } = req.params;
  const access = await verifyWorkspaceAccess(req, workspaceId);
  if (!access.authorized) {
    res.status(access.status).json({ error: access.error });
    return;
  }
  try {
    const searches = dbService.getSearches(workspaceId);
    res.json({ searches });
  } catch (error) {
    res.status(500).json({ error: error.message || "Failed to fetch search history." });
  }
});
dataRouter.post("/workspaces/:workspaceId/searches", async (req, res) => {
  const { workspaceId } = req.params;
  const access = await verifyWorkspaceAccess(req, workspaceId);
  if (!access.authorized) {
    res.status(access.status).json({ error: access.error });
    return;
  }
  const {
    clientId,
    clientName,
    filters,
    candidatesFound,
    validLeads,
    duplicatesRemoved,
    finalLeadCount,
    createdBy
  } = req.body;
  if (!clientId || !clientName || !filters) {
    res.status(400).json({ error: "clientId, clientName, and filters are required." });
    return;
  }
  try {
    const searchId = generateUuid();
    const now = (/* @__PURE__ */ new Date()).toISOString();
    const record = {
      id: searchId,
      workspaceId,
      clientId,
      clientName,
      searchDate: now,
      filters,
      candidatesFound: candidatesFound || 0,
      validLeads: validLeads || 0,
      duplicatesRemoved: duplicatesRemoved || 0,
      finalLeadCount: finalLeadCount || 0,
      createdBy: createdBy || access.user?.email || "User"
    };
    if (supabase) {
      await supabase.from("lead_searches").insert([
        {
          id: searchId,
          workspace_id: workspaceId,
          client_id: clientId,
          filters,
          candidates_found: record.candidatesFound,
          valid_leads: record.validLeads,
          duplicates_removed: record.duplicatesRemoved,
          final_lead_count: record.finalLeadCount,
          created_by_user_email: record.createdBy,
          created_at: now,
          updated_at: now
        }
      ]);
    }
    dbService.saveSearchRecord(
      workspaceId,
      clientId,
      clientName,
      filters,
      record.candidatesFound,
      record.validLeads,
      record.duplicatesRemoved,
      record.finalLeadCount,
      record.createdBy,
      searchId
    );
    res.status(201).json({ search: record });
  } catch (error) {
    res.status(500).json({ error: error.message || "Failed to record search." });
  }
});

// src/server/apiHandler.ts
var apiRouter = express2.Router();
apiRouter.use(express2.json());
apiRouter.use(dataRouter);
apiRouter.use((req, res, next) => {
  if (typeof res.status !== "function") {
    res.status = function(statusCode) {
      res.statusCode = statusCode;
      return res;
    };
  }
  if (typeof res.json !== "function") {
    res.json = function(data) {
      if (!res.headersSent) {
        res.setHeader("Content-Type", "application/json");
      }
      res.end(JSON.stringify(data));
      return res;
    };
  }
  if (!req.query) {
    try {
      const parsed = new URL(req.url || "", "http://localhost");
      const queryObj = {};
      parsed.searchParams.forEach((val, key) => {
        queryObj[key] = val;
      });
      req.query = queryObj;
    } catch {
      req.query = {};
    }
  }
  next();
});
apiRouter.get("/health", (_req, res) => {
  res.json({
    status: "ok",
    service: "LinkedIn Lead Finder API",
    timestamp: (/* @__PURE__ */ new Date()).toISOString()
  });
});
apiRouter.get("/supabase-status", async (_req, res) => {
  try {
    const diag = await testSupabaseHealth();
    res.json(diag);
  } catch (error) {
    res.status(500).json({ error: error.message || "Failed to check Supabase health." });
  }
});
apiRouter.get("/diagnostics", async (_req, res) => {
  try {
    const providerDiag = ServerLeadProviderService.getDiagnostics();
    const supabaseDiag = await testSupabaseHealth();
    res.json({
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      providers: {
        activeProvider: providerDiag.ActiveProvider
      },
      database: {
        clientStatus: supabaseDiag.supabaseClientStatus,
        queryStatus: supabaseDiag.databaseQueryStatus,
        authStatus: supabaseDiag.authServiceStatus
      }
    });
  } catch (error) {
    res.status(500).json({ error: error.message || "Failed to fetch diagnostics." });
  }
});
apiRouter.get("/provider-status", (req, res) => {
  try {
    const statusInfo = ServerLeadProviderService.getStatus();
    res.json(statusInfo);
  } catch (error) {
    res.status(500).json({
      error: error.message || "Failed to check provider status."
    });
  }
});
apiRouter.post("/provider-status/test", async (req, res) => {
  try {
    const result = await ServerLeadProviderService.testConnection();
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message || "Connection test failed." });
  }
});
apiRouter.all("/provider-status/test", async (_req, res) => {
  try {
    const testResult = await ServerLeadProviderService.testConnection();
    res.status(testResult.success ? 200 : 502).json(testResult);
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message || "Failed to execute provider connection test."
    });
  }
});
var executeLeadSearch = async (filters) => {
  filters.maxLeads = Math.min(Math.max(Number(filters.maxLeads) || 50, 1), 500);
  try {
    const rawCandidates = await ServerLeadProviderService.fetchCandidateLeads(filters);
    const dedupeResult = filterAndDeduplicateLeads(rawCandidates);
    return {
      status: 200,
      body: {
        success: true,
        provider: {
          id: "wikidata-provider",
          name: "Wikidata SPARQL Query Service",
          isMock: false
        },
        metrics: {
          rawCandidatesCount: dedupeResult.rawCandidatesCount,
          validRecordsCount: dedupeResult.validRecordsCount,
          duplicateProfilesRemoved: dedupeResult.duplicateProfilesRemoved,
          duplicatePeopleRemoved: dedupeResult.duplicatePeopleRemoved,
          duplicateBusinessesRemoved: dedupeResult.duplicateBusinessesRemoved,
          totalDuplicatesRemoved: dedupeResult.totalDuplicatesRemoved,
          finalLeadCount: dedupeResult.finalUniqueLeads.length
        },
        leads: dedupeResult.finalUniqueLeads
      }
    };
  } catch (error) {
    return {
      status: 502,
      body: {
        error: error.message || "Lead provider temporarily unavailable."
      }
    };
  }
};
apiRouter.post("/search-leads", async (req, res) => {
  const { filters } = req.body;
  if (!filters || typeof filters !== "object") {
    res.status(400).json({ error: "Invalid search filters provided." });
    return;
  }
  const result = await executeLeadSearch(filters);
  res.status(result.status).json(result.body);
});
apiRouter.post("/lead-search-proxy", async (req, res) => {
  const filters = req.body.filters || req.body;
  if (!filters || typeof filters !== "object") {
    res.status(400).json({ error: "Invalid search filters provided." });
    return;
  }
  const result = await executeLeadSearch(filters);
  if (result.status !== 200) {
    res.status(result.status).json(result.body);
    return;
  }
  res.json({
    success: true,
    leads: result.body.leads
  });
});
apiRouter.post("/analyze-profile", async (req, res) => {
  try {
    const { profileUrl } = req.body;
    if (!profileUrl || typeof profileUrl !== "string") {
      res.status(400).json({ error: "LinkedIn profile URL is required." });
      return;
    }
    const linkedInRegex = /https?:\/\/(www\.)?linkedin\.com\/in\/[\w-]+/i;
    if (!linkedInRegex.test(profileUrl.trim())) {
      res.status(400).json({
        error: "Invalid LinkedIn profile URL. Must match format: https://www.linkedin.com/in/example"
      });
      return;
    }
    let icpSummary = {
      jobTitles: ["Founder", "CEO", "Director"],
      industry: ["Technology & SaaS"],
      seniority: ["Director", "VP", "C-Level"],
      country: "United States",
      city: "San Francisco",
      companySize: ["11-50", "51-200"],
      keywords: "SaaS, B2B, Growth"
    };
    res.json({
      success: true,
      profileUrl: profileUrl.trim(),
      icp: icpSummary,
      message: "Profile successfully analyzed and ICP generated."
    });
  } catch (error) {
    res.status(500).json({ error: error.message || "Failed to analyze LinkedIn profile." });
  }
});
apiRouter.post("/discover-instagram", async (req, res) => {
  try {
    const lead = req.body.lead || req.body;
    if (!lead || !lead.fullName) {
      res.status(400).json({ error: "Lead data with fullName is required for Instagram discovery." });
      return;
    }
    const { InstagramDiscoveryService: InstagramDiscoveryService2 } = await Promise.resolve().then(() => (init_instagramDiscoveryService(), instagramDiscoveryService_exports));
    const result = await InstagramDiscoveryService2.discoverForLead({
      leadId: lead.id,
      fullName: lead.fullName,
      companyName: lead.companyName,
      businessWebsite: lead.businessWebsite,
      profileUrl: lead.profileUrl,
      location: lead.location,
      city: lead.businessCity,
      country: lead.businessCountry,
      businessCategory: lead.businessCategory,
      currentUsername: req.body.currentUsername
    });
    res.json({
      success: true,
      result
    });
  } catch (error) {
    res.status(500).json({
      error: error.message || "Failed to discover Instagram business profile."
    });
  }
});
apiRouter.post("/batch-discover-instagram", async (req, res) => {
  try {
    const leads = req.body.leads;
    if (!Array.isArray(leads) || leads.length === 0) {
      res.status(400).json({ error: "Array of leads is required for batch discovery." });
      return;
    }
    const { InstagramDiscoveryService: InstagramDiscoveryService2 } = await Promise.resolve().then(() => (init_instagramDiscoveryService(), instagramDiscoveryService_exports));
    const targets = leads.map((l) => ({
      leadId: l.id,
      fullName: l.fullName,
      companyName: l.companyName,
      businessWebsite: l.businessWebsite,
      profileUrl: l.profileUrl,
      location: l.location,
      city: l.businessCity,
      country: l.businessCountry,
      businessCategory: l.businessCategory
    }));
    const results = await InstagramDiscoveryService2.discoverBatch(targets);
    res.json({
      success: true,
      results
    });
  } catch (error) {
    res.status(500).json({
      error: error.message || "Failed to execute batch Instagram discovery."
    });
  }
});

// src/server/lambda.ts
var app = express3();
app.set("trust proxy", 1);
app.use(express3.json());
app.use((req, res, next) => {
  const origin = req.headers.origin || "*";
  res.header("Access-Control-Allow-Origin", origin);
  res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
  res.header(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept, Authorization, X-Provider-Api-Key, X-Provider-Engine-Id, X-Goog-Api-Key"
  );
  res.header("Access-Control-Allow-Credentials", "true");
  if (req.method === "OPTIONS") {
    return res.sendStatus(200);
  }
  next();
});
app.get("/api/health", (_req, res) => {
  res.json({
    status: "ok",
    service: "LinkedIn Lead Finder API",
    timestamp: (/* @__PURE__ */ new Date()).toISOString()
  });
});
app.get("/health", (_req, res) => {
  res.json({
    status: "ok",
    service: "LinkedIn Lead Finder API",
    timestamp: (/* @__PURE__ */ new Date()).toISOString()
  });
});
app.use("/api", apiRouter);
app.use("/", apiRouter);
app.use((req, res) => {
  res.status(404).json({ error: "API endpoint not found", path: req.url });
});
app.use((err, req, res, _next) => {
  console.error("Unhandled serverless error:", err);
  if (!res.headersSent) {
    res.status(err.status || 500).json({
      error: err.message || "A server error occurred.",
      path: req.url
    });
  }
});
var lambda_default = app;
export {
  lambda_default as default
};
